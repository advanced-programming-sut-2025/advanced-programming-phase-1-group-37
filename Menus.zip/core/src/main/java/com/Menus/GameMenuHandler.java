package com.Menus;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
// import java.util.stream.Collectors; // Not explicitly used

class GameMenuHandler {
    private final CurrentUserContext currentUserContext;
    private final GameService gameService;
    private final UserService userService; // To validate invited users

    public GameMenuHandler(CurrentUserContext currentUserContext, GameService gameService, UserService userService) {
        this.currentUserContext = currentUserContext;
        this.gameService = gameService;
        this.userService = userService;
    }

    public void handleCommand(String command) {
        User loggedInUser = currentUserContext.getCurrentUser(); // The user currently logged into the CLI
        if (loggedInUser == null) {
            System.out.println("Error: No user logged in. Redirecting to Login/Register menu.");
            currentUserContext.navigateTo(MenuState.LOGIN_REGISTER);
            return;
        }

        Map<String, String> args = CommandParser.parseArguments(command);
        String baseCommand = CommandParser.getBaseCommand(command);
        Game currentGame = currentUserContext.getCurrentGame();

        // Commands available when no game is active (in GAME_MENU)
        if (currentUserContext.getCurrentMenu() == MenuState.GAME_MENU && currentGame == null) {
            if (baseCommand.equals("game") && command.startsWith("game new")) {
                processNewGame(args, loggedInUser);
            } else if (baseCommand.equals("load") && command.equalsIgnoreCase("load game")) {
                processLoadGame(loggedInUser);
            } else {
                System.out.println("Error: Unknown command in Game Menu or no active game. Available: game new ..., load game, menu exit, show current menu, exit_program");
            }
            return;
        }

        // Commands available during map selection phase
        if (currentUserContext.getCurrentMenu() == MenuState.GAME_MAP_SELECTION && currentGame != null) {
            if (baseCommand.equals("game") && command.startsWith("game map")) {
                processSelectMap(args, loggedInUser, currentGame);
            } else {
                System.out.println("Error: Invalid command during map selection. Use 'game map <map_number>' or 'menu exit'.");
            }
            return;
        }

        // Commands available when a game is active (IN_GAME)
        if (currentUserContext.getCurrentMenu() == MenuState.IN_GAME && currentGame != null) {
            if (baseCommand.equals("next") && command.equalsIgnoreCase("next turn")) {
                processNextTurn(loggedInUser, currentGame);
            } else if (baseCommand.equals("exit") && command.equalsIgnoreCase("exit game")) {
                processExitGame(loggedInUser, currentGame);
            }
            else {
                System.out.println("Error: Unknown command while in game. Available: next turn, exit game, menu exit, show current menu, exit_program");
            }
            return;
        }

        // If in GAME_MENU but a game IS active (e.g., just exited IN_GAME to GAME_MENU)
        if (currentUserContext.getCurrentMenu() == MenuState.GAME_MENU && currentGame != null) {
            if (baseCommand.equals("exit") && command.equalsIgnoreCase("exit game")) {
                processExitGame(loggedInUser, currentGame);
            } else if (baseCommand.equals("load") && command.equalsIgnoreCase("load game")) {
                System.out.println("A game is already loaded. Exit current game first or use 'menu exit' to go to Main Menu.");
            }
            else {
                System.out.println("Game is loaded. You can 'exit game', or use 'menu exit' to go to Main Menu.");
            }
            return;
        }

        System.out.println("Error: Command not recognized or not applicable in current game state ("+currentUserContext.getCurrentMenu()+").");
    }

    private void processNewGame(Map<String, String> args, User creator) {
        if (gameService.isUserInAnySavedGame(creator.getUsername())) {
            System.out.println("Error: You are already part of a game. Load it or ask the main player to delete it.");
            return;
        }

        String usersStr = args.get("u");
        if (usersStr == null || usersStr.isEmpty()) {
            System.out.println("Error: No users specified for the new game. Usage: game new -u \"<user1> <user2> <user3>\"");
            System.out.println("Note: If inviting multiple users, enclose their usernames in quotes after the -u flag.");
            return;
        }
        List<String> invitedUsernames = new ArrayList<>(Arrays.asList(usersStr.split("\\s+")));
        invitedUsernames.remove(creator.getUsername());


        if (invitedUsernames.size() < 1 || invitedUsernames.size() > 3) {
            System.out.println("Error: Must invite 1 to 3 other players (excluding yourself). You are automatically included.");
            return;
        }

        for (String invitedUsername : invitedUsernames) {
            if (userService.findUserByUsername(invitedUsername).isEmpty()) {
                System.out.println("Error: Invited user '" + invitedUsername + "' does not exist.");
                return;
            }
            if (gameService.isUserInAnySavedGame(invitedUsername)) {
                System.out.println("Error: Invited user '" + invitedUsername + "' is already in a game.");
                return;
            }
            if (invitedUsername.equals(creator.getUsername())) {
                System.out.println("Error: Cannot invite yourself to the game via the -u flag.");
                return;
            }
        }

        long distinctCount = invitedUsernames.stream().distinct().count();
        if (distinctCount != invitedUsernames.size()) {
            System.out.println("Error: Duplicate usernames in the invitation list.");
            return;
        }

        Game newGame = gameService.createNewGame(creator, invitedUsernames);
        if (newGame != null) {
            currentUserContext.setCurrentGame(newGame);
            currentUserContext.navigateTo(MenuState.GAME_MAP_SELECTION);
            System.out.println("New game created with ID: " + newGame.getGameId() + ". Players: " + String.join(", ", newGame.getPlayerUsernames()));
            promptForMapSelection(newGame);
        } else {
            System.out.println("Error: Failed to create new game.");
        }
    }

    private void promptForMapSelection(Game game) {
        String playerToSelect = game.getCurrentPlayerUsernameForMapSelection();
        if (playerToSelect != null) {
            System.out.println("Player " + playerToSelect + ", it's your turn to select a map.");
            System.out.println("Available maps: 1 (Standard), 2 (Riverland), 3 (Forest), 4 (Hill-top), 5 (Wilderness)");
            System.out.println("Use command: game map <map_number>");
        }
    }

    private void processSelectMap(Map<String, String> args, User loggedInUser, Game game) {
        String playerWhoseTurnItIs = game.getCurrentPlayerUsernameForMapSelection();

        if (playerWhoseTurnItIs == null) {
            if (game.areAllMapsSelected()) {
                currentUserContext.navigateTo(MenuState.IN_GAME);
                System.out.println("All maps selected. Game started! It's " + game.getCurrentPlayerForTurn() + "'s turn.");
            } else {
                System.out.println("Error: Map selection incomplete, but no player to select. Please check game state.");
            }
            return;
        }

        String mapNumStr = args.get("map_number_implicit");
        if (mapNumStr == null) {
            String fullCommand = args.get("_full_command_");
            if (fullCommand != null && fullCommand.matches("game map \\d+")) {
                mapNumStr = fullCommand.split("\\s+")[2];
            }
        }

        if (mapNumStr == null) {
            System.out.println("Error: Missing map number. Usage: game map <map_number>");
            System.out.println("Player " + playerWhoseTurnItIs + ", please enter your map choice: game map <map_number>");
            return;
        }

        try {
            int mapNumber = Integer.parseInt(mapNumStr);
            if (mapNumber < 1 || mapNumber > 5) {
                System.out.println("Error: Invalid map number. Choose between 1 and 5.");
                System.out.println("Player " + playerWhoseTurnItIs + ", please enter a valid map choice: game map <map_number>");
                return;
            }

            game.getPlayerMapChoices().put(playerWhoseTurnItIs, mapNumber);
            System.out.println(playerWhoseTurnItIs + " selected map " + mapNumber + ".");

            String nextPlayerToSelect = game.getCurrentPlayerUsernameForMapSelection();

            if (game.areAllMapsSelected()) {
                gameService.saveGame(game);
                System.out.println("All players have selected their maps. Starting game...");
                currentUserContext.navigateTo(MenuState.IN_GAME);
                System.out.println("Game started! It's " + game.getCurrentPlayerForTurn() + "'s turn.");
            } else {
                gameService.saveGame(game);
                promptForMapSelection(game);
            }

        } catch (NumberFormatException e) {
            System.out.println("Error: Invalid map number format.");
            System.out.println("Player " + playerWhoseTurnItIs + ", please enter a valid map number: game map <map_number>");
        }
    }

    private void processLoadGame(User loggedInUser) {
        Game loadedGame = gameService.loadGameForUser(loggedInUser.getUsername());
        if (loadedGame != null) {
            currentUserContext.setCurrentGame(loadedGame);
            if (loadedGame.areAllMapsSelected()) {
                currentUserContext.navigateTo(MenuState.IN_GAME);
                System.out.println("Game loaded. It's " + loadedGame.getCurrentPlayerForTurn() + "'s turn.");
            } else {
                currentUserContext.navigateTo(MenuState.GAME_MAP_SELECTION);
                System.out.println("Game loaded. Resuming map selection.");
                promptForMapSelection(loadedGame);
            }
        } else {
            System.out.println("Error: No saved game found for your user or failed to load.");
        }
    }

    /**
     * Processes the 'next turn' command.
     * The loggedInUser is the user at the CLI. The game's turn advances for game.getCurrentPlayerForTurn().
     * As per PDF, the CLI operator can advance turns for any player in the current game session.
     * @param loggedInUser The user currently operating the CLI. (Not directly used for turn logic, but good for context)
     * @param game The current game instance.
     */
    private void processNextTurn(User loggedInUser, Game game) {
        if (game == null || game.getCurrentPlayerForTurn() == null) {
            System.out.println("Error: No active game or no current player to advance turn for.");
            return;
        }

        String playerWhoseTurnIsEnding = game.getCurrentPlayerForTurn();

        System.out.println(playerWhoseTurnIsEnding + " ends their turn."); // Simplified message

        game.nextTurn(); // Advances the turn within the Game object

        // Call saveGame, which will print its own "Game progress saved." message if successful.
        // No need to print it here again.
        gameService.saveGame(game);

        System.out.println("It's now " + game.getCurrentPlayerForTurn() + "'s turn.");
    }

    private void processExitGame(User loggedInUser, Game game) {
        if (game == null) {
            System.out.println("Error: No active game to exit.");
            return;
        }
        if (!loggedInUser.getUsername().equals(game.getMainPlayerUsername())) {
            System.out.println("Error: Only the main player (" + game.getMainPlayerUsername() + ") can exit the game session. You are " + loggedInUser.getUsername() + ".");
            return;
        }
        if (!game.getMainPlayerUsername().equals(game.getCurrentPlayerForTurn())) {
            System.out.println("Error: The main player (" + game.getMainPlayerUsername() + ") can only exit the game when it is their turn. It is currently " + game.getCurrentPlayerForTurn() + "'s turn.");
            return;
        }

        gameService.saveGame(game);
        currentUserContext.setCurrentGame(null);
        currentUserContext.navigateTo(MenuState.GAME_MENU);
        System.out.println("Game session exited and saved by " + loggedInUser.getUsername() + ". You are now in the Game Menu.");
    }
}
