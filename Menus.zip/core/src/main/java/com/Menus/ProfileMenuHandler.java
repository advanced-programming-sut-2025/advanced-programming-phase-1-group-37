package com.Menus;// Handles commands for the Profile Menu
import java.util.Map;

class ProfileMenuHandler {
    private final CurrentUserContext currentUserContext;
    private final UserService userService;

    public ProfileMenuHandler(CurrentUserContext currentUserContext, UserService userService) {
        this.currentUserContext = currentUserContext;
        this.userService = userService;
    }

    public void handleCommand(String command) {
        Map<String, String> args = CommandParser.parseArguments(command);
        String baseCommand = CommandParser.getBaseCommand(command);
        User currentUser = currentUserContext.getCurrentUser();

        if (currentUser == null) {
            System.out.println("Error: No user logged in. Redirecting to Login/Register menu.");
            currentUserContext.navigateTo(MenuState.LOGIN_REGISTER);
            return;
        }

        switch (baseCommand) {
            case "change":
                processChangeCommand(command, args, currentUser);
                break;
            case "user": // "user info"
                if (command.equalsIgnoreCase("user info")) {
                    displayUserInfo(currentUser);
                } else {
                    System.out.println("Error: Unknown user command. Did you mean 'user info'?");
                }
                break;
            default:
                System.out.println("Error: Unknown command in Profile Menu. Available: change ..., user info, menu exit, show current menu, exit_program");
        }
    }

    private void processChangeCommand(String fullCommand, Map<String, String> args, User currentUser) {
        if (fullCommand.startsWith("change username")) {
            String newUsername = args.get("u");
            if (newUsername != null) System.out.println(userService.changeUsername(currentUser, newUsername));
            else System.out.println("Error: Missing new username. Usage: change username -u <new_username>");
        } else if (fullCommand.startsWith("change nickname")) {
            String newNickname = args.get("n"); // PDF has -u for nickname, assuming -n is more logical
            if (newNickname != null) System.out.println(userService.changeNickname(currentUser, newNickname));
            else System.out.println("Error: Missing new nickname. Usage: change nickname -n <new_nickname>");
        } else if (fullCommand.startsWith("change email")) {
            String newEmail = args.get("e");
            if (newEmail != null) System.out.println(userService.changeEmail(currentUser, newEmail));
            else System.out.println("Error: Missing new email. Usage: change email -e <new_email>");
        } else if (fullCommand.startsWith("change password")) {
            String newPassword = args.get("p");
            String oldPassword = args.get("o");
            if (newPassword != null && oldPassword != null) {
                System.out.println(userService.changePassword(currentUser, oldPassword, newPassword));
            } else {
                System.out.println("Error: Missing arguments. Usage: change password -p <new_password> -o <old_password>");
            }
        } else {
            System.out.println("Error: Unknown change command. Available: change username, change nickname, change email, change password.");
        }
    }

    private void displayUserInfo(User user) {
        System.out.println("--- User Information ---");
        System.out.println("Username: " + user.getUsername());
        System.out.println("Nickname: " + user.getNickname());
        System.out.println("Email: " + user.getEmail()); // Not in PDF list, but good to have
        System.out.println("Gender: " + user.getGender()); // Not in PDF list, but good to have
        System.out.println("Highest Money Earned: " + user.getHighestMoneyEarned());
        System.out.println("Games Played: " + user.getGamesPlayed());
        System.out.println("------------------------");
    }
}
