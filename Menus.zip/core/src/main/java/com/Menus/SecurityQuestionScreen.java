// File: com/Menus/SecurityQuestionScreen.java
package com.Menus;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

// Make sure these imports are here for background scaling
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Scaling;

import java.util.List;

public class SecurityQuestionScreen implements Screen {

    private final StardewGdxGame game;
    private final Stage stage;
    private final String username;

    public SecurityQuestionScreen(final StardewGdxGame game, final String username) {
        this.game = game;
        this.stage = new Stage(new ScreenViewport());
        this.username = username;
        Skin skin = game.skin;

        Table table = new Table();
        table.setFillParent(true);
        table.center();
        stage.addActor(table);

        final Label titleLabel = new Label("Set Your Security Question", skin, "default");
        final Label messageLabel = new Label("Select a question and provide an answer.", skin);

        final SelectBox<String> questionSelectBox = new SelectBox<>(skin);
        List<String> questionList = SecurityQuestion.getQuestionList();

        // This is the corrected line for the dropdown menu
        questionSelectBox.setItems(questionList.toArray(new String[0]));

        final TextField answerField = new TextField("", skin);
        final TextField confirmAnswerField = new TextField("", skin);
        final TextButton submitButton = new TextButton("Submit", skin);

        table.add(titleLabel).colspan(2).padBottom(20);
        table.row();
        table.add(messageLabel).colspan(2).padBottom(20);
        table.row();
        table.add(new Label("Question:", skin)).left();
        table.add(questionSelectBox).width(400).padBottom(10);
        table.row();
        table.add(new Label("Answer:", skin)).left();
        table.add(answerField).width(400).padBottom(10);
        table.row();
        table.add(new Label("Confirm Answer:", skin)).left();
        table.add(confirmAnswerField).width(400).padBottom(20);
        table.row();
        table.add(submitButton).colspan(2);

        submitButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                int questionNumber = questionSelectBox.getSelectedIndex() + 1;
                String answer = answerField.getText();
                String confirmAnswer = confirmAnswerField.getText();

                String result = game.userService.setSecurityQuestionForUser(
                    username,
                    questionNumber,
                    answer,
                    confirmAnswer
                );

                messageLabel.setText(result);

                if (result.startsWith("Security question set successfully")) {
                    game.setScreen(new LoginScreen(game));
                }
            }
        });
    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
    }

    @Override
    public void render(float delta) {
        // This is the non-stretching background render method.
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        float screenWidth = Gdx.graphics.getWidth();
        float screenHeight = Gdx.graphics.getHeight();
        float imageWidth = game.backgroundTexture.getWidth();
        float imageHeight = game.backgroundTexture.getHeight();

        Vector2 size = Scaling.fill.apply(imageWidth, imageHeight, screenWidth, screenHeight);

        float x = (screenWidth - size.x) / 2;
        float y = (screenHeight - size.y) / 2;

        game.batch.begin();
        game.batch.draw(game.backgroundTexture, x, y, size.x, size.y);
        game.batch.end();

        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void dispose() {
        stage.dispose();
    }

    @Override
    public void pause() {}
    @Override
    public void resume() {}
    @Override
    public void hide() {}
}
