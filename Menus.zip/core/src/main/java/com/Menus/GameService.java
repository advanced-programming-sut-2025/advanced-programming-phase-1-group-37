package com.Menus;// Manages game instances, creation, loading, saving

import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

class GameService {
    // private List<Game> activeGames; // Could also be just one active game at a time in CurrentUserContext
    private List<Game> savedGames;  // All games persisted
    private static final String GAMES_FILE_PATH = "games.json";
    private UserService userService;

    public GameService(UserService userService) {
        // this.activeGames = new ArrayList<>();
        this.savedGames = new ArrayList<>();
        this.userService = userService;
        loadGames();
    }

    public void loadGames() {
        Type gameListType = new TypeToken<ArrayList<Game>>() {}.getType();
        this.savedGames = JsonUtil.loadData(GAMES_FILE_PATH, gameListType);
        if (this.savedGames == null) {
            this.savedGames = new ArrayList<>();
        }
    }

    public void saveGames() {
        JsonUtil.saveData(savedGames, GAMES_FILE_PATH);
    }

    public Game createNewGame(User creator, List<String> invitedUsernames) {
        // Check if creator or invited players are already in another active game
        if (isUserInAnySavedGame(creator.getUsername())) {
            System.out.println("Error: " + creator.getUsername() + " is already part of another game.");
            return null;
        }
        for (String invitedUsername : invitedUsernames) {
            if (isUserInAnySavedGame(invitedUsername)) {
                System.out.println("Error: Invited player " + invitedUsername + " is already part of another game.");
                return null;
            }
            if (userService.findUserByUsername(invitedUsername).isEmpty()){
                System.out.println("Error: Invited player " + invitedUsername + " does not exist.");
                return null;
            }
        }

        Game newGame = new Game(creator.getUsername(), invitedUsernames);
        savedGames.add(newGame); // Add to list of all games
        // activeGames.add(newGame); // If managing multiple active games (less likely for CLI)
        saveGames();
        creator.setGamesPlayed(creator.getGamesPlayed() + 1); // Update creator's stats
        userService.saveUsers(); // Save updated user stats
        return newGame;
    }

    public Optional<Game> findSavedGameByPlayer(String username) {
        return savedGames.stream()
                .filter(g -> g.getPlayerUsernames().contains(username))
                .findFirst();
    }

    public boolean isUserInAnySavedGame(String username) {
        return savedGames.stream().anyMatch(g -> g.isPlayerInGame(username));
    }


    public Game loadGameForUser(String username) {
        Optional<Game> gameOpt = findSavedGameByPlayer(username);
        if (gameOpt.isPresent()) {
            Game gameToLoad = gameOpt.get();
            // If the game was saved mid-map-selection, it should resume from there.
            // If game was fully started, it loads into IN_GAME state.
            // The Game object itself holds the state (like allMapsSelected).
            gameToLoad.setMainPlayerUsername(username); // The player loading becomes the main player for this session
            System.out.println("Game loaded. Main player for this session: " + username);
            saveGames(); // Save updated main player
            return gameToLoad;
        }
        return null;
    }

    public boolean saveGame(Game game) {
        if (game == null) return false;
        // If the game is already in savedGames, it will be updated by reference when saveGames() is called.
        // If it's a new game or needs explicit add/update:
        Optional<Game> existingGameOpt = savedGames.stream().filter(g -> g.getGameId().equals(game.getGameId())).findFirst();
        if (existingGameOpt.isEmpty()) {
            savedGames.add(game);
        } else {
            // If game objects are managed by reference, changes to 'game' are already reflected in 'existingGameOpt.get()'.
            // If they could be different instances with the same ID, you might need to remove and add:
            // savedGames.remove(existingGameOpt.get());
            // savedGames.add(game);
            // For now, assuming 'game' is the instance from 'savedGames' or a new one to be added.
        }
        saveGames(); // This will save the entire list, including the modified 'game' if it was already in the list.
        System.out.println("Game progress saved.");
        return true;
    }

    public boolean deleteGame(Game game) {
        if (game == null) return false;
        boolean removed = savedGames.removeIf(g -> g.getGameId().equals(game.getGameId()));
        if (removed) {
            // activeGames.removeIf(g -> g.getGameId().equals(game.getGameId())); // If managing activeGames list
            saveGames();
            System.out.println("Game " + game.getGameId() + " deleted.");
        }
        return removed;
    }
}
