// File: com/Menus/ProfileScreen.java
package com.Menus;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Scaling;

public class ProfileScreen implements Screen {

    private final StardewGdxGame game;
    private final Stage stage;
    private final Skin skin;

    // We need to be able to update these labels and the image
    private Label usernameLabel;
    private Label nicknameLabel;
    private Label emailLabel;
    private Label genderLabel;
    private Label moneyLabel;
    private Label gamesPlayedLabel;
    private Image currentAvatarImage; // *** NEW: To display the avatar ***

    public ProfileScreen(final StardewGdxGame game) {
        this.game = game;
        this.stage = new Stage(new ScreenViewport());
        this.skin = game.skin;

        // Main table for layout
        Table table = new Table();
        table.setFillParent(true);
        table.top().pad(50);
        stage.addActor(table);

        User currentUser = game.currentUserContext.getCurrentUser();

        // *** NEW: Create the avatar image from the loaded textures ***
        currentAvatarImage = new Image(game.avatarTextures[currentUser.getAvatarId()]);

        // Create a separate table for the user info to align it next to the avatar
        Table infoTable = new Table();

        // Initialize the labels with current user data
        usernameLabel = new Label(currentUser.getUsername(), skin);
        nicknameLabel = new Label(currentUser.getNickname(), skin);
        emailLabel = new Label(currentUser.getEmail(), skin);
        genderLabel = new Label(currentUser.getGender(), skin);
        moneyLabel = new Label(String.valueOf(currentUser.getHighestMoneyEarned()), skin);
        gamesPlayedLabel = new Label(String.valueOf(currentUser.getGamesPlayed()), skin);

        TextButton changeAvatarButton = new TextButton("Change Avatar", skin);
        TextButton changeNicknameButton = new TextButton("Change Nickname", skin);
        TextButton changePasswordButton = new TextButton("Change Password", skin);
        TextButton backButton = new TextButton("Back to Main Menu", skin);

        // --- Layout ---
        table.add(new Label("User Profile", skin, "default")).colspan(2).padBottom(40).center();
        table.row();

        // Add the avatar to the main table on the left
        table.add(currentAvatarImage).top().padRight(30);
        // Add the info table to the main table on the right
        table.add(infoTable).top().left();

        // Populate the info table
        infoTable.add(new Label("Username:", skin)).left().padRight(20);
        infoTable.add(usernameLabel).left();
        infoTable.row().padTop(10);
        infoTable.add(new Label("Nickname:", skin)).left();
        infoTable.add(nicknameLabel).left();
        infoTable.row().padTop(10);
        infoTable.add(new Label("Email:", skin)).left();
        infoTable.add(emailLabel).left();
        infoTable.row().padTop(10);
        infoTable.add(new Label("Gender:", skin)).left();
        infoTable.add(genderLabel).left();
        infoTable.row().padTop(10);
        infoTable.add(new Label("Highest Money:", skin)).left();
        infoTable.add(moneyLabel).left();
        infoTable.row().padTop(10);
        infoTable.add(new Label("Games Played:", skin)).left();
        infoTable.add(gamesPlayedLabel).left();

        // Add buttons below everything else
        table.row().padTop(40);
        Table buttonTable = new Table();
        buttonTable.add(changeAvatarButton).padBottom(10).row();
        buttonTable.add(changeNicknameButton).padBottom(10).row();
        buttonTable.add(changePasswordButton).padBottom(10).row();
        buttonTable.add(backButton).padTop(20);
        table.add(buttonTable).colspan(2);


        // --- Event Listeners ---
        backButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.setScreen(new MainMenuScreen(game));
            }
        });

        // *** NEW: Listener for the change avatar button ***
        changeAvatarButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                showChangeAvatarDialog();
            }
        });

        changeNicknameButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                showChangeNicknameDialog();
            }
        });

        changePasswordButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                showChangePasswordDialog();
            }
        });
    }

    // *** NEW: Dialog for changing avatar ***
    private void showChangeAvatarDialog() {
        final Dialog dialog = new Dialog("Choose an Avatar", skin);
        Table content = dialog.getContentTable();

        // Create an ImageButton for each avatar
        for (int i = 0; i < 4; i++) {
            final int avatarId = i; // final variable for use in listener
            ImageButton avatarButton = new ImageButton(new TextureRegionDrawable(new TextureRegion(game.avatarTextures[i])));
            content.add(avatarButton).pad(10);

            avatarButton.addListener(new ChangeListener() {
                @Override
                public void changed(ChangeEvent event, Actor actor) {
                    User currentUser = game.currentUserContext.getCurrentUser();
                    game.userService.changeAvatar(currentUser, avatarId);
                    // Update the image on the profile screen
                    currentAvatarImage.setDrawable(new TextureRegionDrawable(new TextureRegion(game.avatarTextures[avatarId])));
                    dialog.hide();
                }
            });
        }

        dialog.button("Cancel");
        dialog.show(stage);
    }

    // --- DIALOGS for changing user info ---
    private void showChangeNicknameDialog() {
        final Dialog dialog = new Dialog("Change Nickname", skin);
        final TextField newNicknameField = new TextField("", skin);
        final Label messageLabel = new Label("", skin);

        dialog.text("Enter your new nickname:");
        dialog.getContentTable().row();
        dialog.getContentTable().add(newNicknameField).width(200);
        dialog.getContentTable().row();
        dialog.getContentTable().add(messageLabel);

        TextButton confirmButton = new TextButton("Confirm", skin);
        dialog.button(confirmButton);
        dialog.button("Cancel");

        confirmButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                User currentUser = game.currentUserContext.getCurrentUser();
                String newNickname = newNicknameField.getText();
                String result = game.userService.changeNickname(currentUser, newNickname);

                if (result.startsWith("Nickname changed successfully")) {
                    nicknameLabel.setText(newNickname);
                    dialog.hide();
                } else {
                    messageLabel.setText(result);
                }
            }
        });

        dialog.show(stage);
    }

    private void showChangePasswordDialog() {
        final Dialog dialog = new Dialog("Change Password", skin);
        final TextField oldPasswordField = new TextField("", skin);
        oldPasswordField.setPasswordMode(true);
        oldPasswordField.setPasswordCharacter('*');
        final TextField newPasswordField = new TextField("", skin);
        newPasswordField.setPasswordMode(true);
        newPasswordField.setPasswordCharacter('*');
        final Label messageLabel = new Label("", skin);

        Table content = dialog.getContentTable();
        content.add(new Label("Old Password:", skin)).left();
        content.add(oldPasswordField).width(200).padBottom(10);
        content.row();
        content.add(new Label("New Password:", skin)).left();
        content.add(newPasswordField).width(200).padBottom(10);
        content.row();
        content.add(messageLabel).colspan(2);

        TextButton confirmButton = new TextButton("Confirm", skin);
        dialog.button(confirmButton);
        dialog.button("Cancel");

        confirmButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                User currentUser = game.currentUserContext.getCurrentUser();
                String oldPassword = oldPasswordField.getText();
                String newPassword = newPasswordField.getText();
                String result = game.userService.changePassword(currentUser, oldPassword, newPassword);

                if (result.startsWith("Password changed successfully")) {
                    dialog.hide();
                } else {
                    messageLabel.setText(result);
                }
            }
        });

        dialog.show(stage);
    }


    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        float screenWidth = Gdx.graphics.getWidth();
        float screenHeight = Gdx.graphics.getHeight();
        float imageWidth = game.backgroundTexture.getWidth();
        float imageHeight = game.backgroundTexture.getHeight();

        Vector2 size = Scaling.fill.apply(imageWidth, imageHeight, screenWidth, screenHeight);
        float x = (screenWidth - size.x) / 2;
        float y = (screenHeight - size.y) / 2;

        game.batch.begin();
        game.batch.draw(game.backgroundTexture, x, y, size.x, size.y);
        game.batch.end();

        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void dispose() {
        stage.dispose();
    }

    @Override
    public void pause() {}
    @Override
    public void resume() {}
    @Override
    public void hide() {}
}
