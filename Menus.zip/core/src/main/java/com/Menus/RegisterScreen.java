// File: com/Menus/RegisterScreen.java
package com.Menus;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

// Make sure these imports are here for background scaling
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Scaling;

public class RegisterScreen implements Screen {

    private final StardewGdxGame game;
    private final Stage stage;
    private final Label messageLabel;

    public RegisterScreen(final StardewGdxGame game) {
        this.game = game;
        this.stage = new Stage(new ScreenViewport());
        Skin skin = game.skin;

        Table table = new Table();
        table.setFillParent(true);
        table.center();
        stage.addActor(table);

        // --- UI Elements ---
        final TextField usernameField = new TextField("", skin);
        final TextField passwordField = new TextField("", skin);
        passwordField.setPasswordMode(true);
        passwordField.setPasswordCharacter('*');
        final TextField confirmPasswordField = new TextField("", skin);
        confirmPasswordField.setPasswordMode(true);
        confirmPasswordField.setPasswordCharacter('*');
        final TextField nicknameField = new TextField("", skin);
        final TextField emailField = new TextField("", skin);
        final TextField genderField = new TextField("", skin);

        final TextButton randomPasswordButton = new TextButton("Generate", skin);

        messageLabel = new Label("Please fill out all fields.", skin);
        TextButton registerButton = new TextButton("Register", skin);
        TextButton backButton = new TextButton("Back to Login", skin);

        // --- Layout ---
        table.add(new Label("Register New User", skin, "default")).colspan(3).padBottom(20);
        table.row();
        table.add(new Label("Username:", skin)).left();
        table.add(usernameField).width(250).colspan(2).padBottom(10);
        table.row();

        table.add(new Label("Password:", skin)).left();
        table.add(passwordField).width(160).padRight(10);
        table.add(randomPasswordButton).width(80).padBottom(10);
        table.row();

        table.add(new Label("Confirm Password:", skin)).left();
        table.add(confirmPasswordField).width(250).colspan(2).padBottom(10);
        table.row();
        table.add(new Label("Nickname:", skin)).left();
        table.add(nicknameField).width(250).colspan(2).padBottom(10);
        table.row();
        table.add(new Label("Email:", skin)).left();
        table.add(emailField).width(250).colspan(2).padBottom(10);
        table.row();
        table.add(new Label("Gender:", skin)).left();
        table.add(genderField).width(250).colspan(2).padBottom(20);
        table.row();
        table.add(messageLabel).colspan(3).padBottom(20);
        table.row();

        Table bottomButtonTable = new Table();
        bottomButtonTable.add(registerButton).padRight(10);
        bottomButtonTable.add(backButton);
        table.add(bottomButtonTable).colspan(3);


        // --- Event Listeners ---

        // Listener for the Generate button
        randomPasswordButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                String randomPassword = PasswordService.generateRandomPassword();

                // *** NEW: Make the password fields visible ***
                passwordField.setPasswordMode(false);
                confirmPasswordField.setPasswordMode(false);

                passwordField.setText(randomPassword);
                confirmPasswordField.setText(randomPassword);
            }
        });

        // *** NEW: Listener to re-hide the password if the user clicks the field ***
        ClickListener manualPasswordListener = new ClickListener() {
            @Override
            public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
                // If the password is currently visible (from being generated)...
                if (!passwordField.isPasswordMode()) {
                    // ...hide it again.
                    passwordField.setPasswordMode(true);
                    confirmPasswordField.setPasswordMode(true);
                    // And clear the text so the user can type their own.
                    passwordField.setText("");
                    confirmPasswordField.setText("");
                }
                // Return false to allow other listeners (like for typing) to work.
                return false;
            }
        };
        passwordField.addListener(manualPasswordListener);
        confirmPasswordField.addListener(manualPasswordListener);


        registerButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                final String username = usernameField.getText();
                String result = game.userService.registerUser(
                    username,
                    passwordField.getText(),
                    confirmPasswordField.getText(),
                    nicknameField.getText(),
                    emailField.getText(),
                    genderField.getText()
                );

                if (result.startsWith("User registered successfully")) {
                    game.setScreen(new SecurityQuestionScreen(game, username));
                } else {
                    messageLabel.setText(result);
                }
            }
        });

        backButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.setScreen(new LoginScreen(game));
            }
        });
    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        float screenWidth = Gdx.graphics.getWidth();
        float screenHeight = Gdx.graphics.getHeight();
        float imageWidth = game.backgroundTexture.getWidth();
        float imageHeight = game.backgroundTexture.getHeight();

        Vector2 size = Scaling.fill.apply(imageWidth, imageHeight, screenWidth, screenHeight);

        float x = (screenWidth - size.x) / 2;
        float y = (screenHeight - size.y) / 2;

        game.batch.begin();
        game.batch.draw(game.backgroundTexture, x, y, size.x, size.y);
        game.batch.end();

        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void dispose() {
        stage.dispose();
    }

    @Override
    public void pause() {}
    @Override
    public void resume() {}
    @Override
    public void hide() {}
}
