// File: com/Menus/MainMenuScreen.java
package com.Menus;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Scaling;

public class MainMenuScreen implements Screen {

    private final StardewGdxGame game;
    private final Stage stage;

    public MainMenuScreen(final StardewGdxGame game) {
        this.game = game;
        this.stage = new Stage(new ScreenViewport());

        Table table = new Table();
        table.setFillParent(true);
        table.center();
        stage.addActor(table);

        String welcomeMessage = "Welcome, " + game.currentUserContext.getCurrentUser().getNickname();
        Label welcomeLabel = new Label(welcomeMessage, game.skin, "default");

        TextButton profileButton = new TextButton("Profile", game.skin);
        TextButton gameButton = new TextButton("Play Game", game.skin);
        TextButton logoutButton = new TextButton("Logout", game.skin);

        table.add(welcomeLabel).padBottom(40);
        table.row();
        table.add(profileButton).width(200).padBottom(10);
        table.row();
        table.add(gameButton).width(200).padBottom(10);
        table.row();
        table.add(logoutButton).width(200).padTop(30);

        logoutButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.currentUserContext.logout();
                game.setScreen(new LoginScreen(game));
            }
        });

        profileButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.setScreen(new ProfileScreen(game));
            }
        });

        // *** THIS IS THE NEW CODE ***
        gameButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.setScreen(new GameMenuScreen(game));
            }
        });
    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        float screenWidth = Gdx.graphics.getWidth();
        float screenHeight = Gdx.graphics.getHeight();
        float imageWidth = game.backgroundTexture.getWidth();
        float imageHeight = game.backgroundTexture.getHeight();

        Vector2 size = Scaling.fill.apply(imageWidth, imageHeight, screenWidth, screenHeight);
        float x = (screenWidth - size.x) / 2;
        float y = (screenHeight - size.y) / 2;

        game.batch.begin();
        game.batch.draw(game.backgroundTexture, x, y, size.x, size.y);
        game.batch.end();

        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void dispose() {
        stage.dispose();
    }

    @Override
    public void pause() {}
    @Override
    public void resume() {}
    @Override
    public void hide() {}
}
