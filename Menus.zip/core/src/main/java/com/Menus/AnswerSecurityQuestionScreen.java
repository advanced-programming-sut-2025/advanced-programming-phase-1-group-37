// File: com/Menus/AnswerSecurityQuestionScreen.java
package com.Menus;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Scaling;
import java.util.List;

public class AnswerSecurityQuestionScreen implements Screen {

    private final StardewGdxGame game;
    private final Stage stage;
    private final String username;

    public AnswerSecurityQuestionScreen(final StardewGdxGame game, final String username, SecurityQuestion question) {
        this.game = game;
        this.stage = new Stage(new ScreenViewport());
        this.username = username;
        Skin skin = game.skin;

        Table table = new Table();
        table.setFillParent(true);
        table.center();
        stage.addActor(table);

        // Get the text of the question from the master list
        List<String> questionList = SecurityQuestion.getQuestionList();
        String questionText = "Question not found.";
        if (question.getQuestionNumber() > 0 && question.getQuestionNumber() <= questionList.size()) {
            questionText = questionList.get(question.getQuestionNumber() - 1);
        }

        // --- UI Elements ---
        final Label questionLabel = new Label(questionText, skin, "default");
        final TextField answerField = new TextField("", skin);
        final TextField newPasswordField = new TextField("", skin);
        newPasswordField.setPasswordMode(true);
        newPasswordField.setPasswordCharacter('*');
        final TextField confirmNewPasswordField = new TextField("", skin);
        confirmNewPasswordField.setPasswordMode(true);
        confirmNewPasswordField.setPasswordCharacter('*');

        final Label messageLabel = new Label("Please answer the question and set a new password.", skin);
        final TextButton submitButton = new TextButton("Reset Password", skin);
        final TextButton backButton = new TextButton("Back to Login", skin);

        // --- Layout ---
        table.add(new Label("Answer Security Question", skin, "default")).colspan(2).padBottom(20);
        table.row();
        table.add(questionLabel).colspan(2).padBottom(20);
        table.row();
        table.add(new Label("Your Answer:", skin)).left();
        table.add(answerField).width(300).padBottom(10);
        table.row();
        table.add(new Label("New Password:", skin)).left();
        table.add(newPasswordField).width(300).padBottom(10);
        table.row();
        table.add(new Label("Confirm New Password:", skin)).left();
        table.add(confirmNewPasswordField).width(300).padBottom(20);
        table.row();
        table.add(messageLabel).colspan(2).padBottom(20);
        table.row();
        table.add(submitButton).padRight(10);
        table.add(backButton);

        // --- Event Listener ---
        submitButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                String answer = answerField.getText();
                String newPassword = newPasswordField.getText();
                String confirmNewPassword = confirmNewPasswordField.getText();

                // First, verify the answer
                if (!game.userService.verifySecurityAnswer(username, answer)) {
                    messageLabel.setText("Error: Incorrect answer.");
                    return; // Stop processing
                }

                // If answer is correct, check if passwords match
                if (!newPassword.equals(confirmNewPassword)) {
                    messageLabel.setText("Error: New passwords do not match.");
                    return; // Stop processing
                }

                // If passwords match, try to update it
                String result = game.userService.updateUserPassword(username, newPassword);
                messageLabel.setText(result);

                if (result.startsWith("Password updated successfully")) {
                    // On success, you could automatically go to the login screen
                    // game.setScreen(new LoginScreen(game));
                }
            }
        });

        backButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.setScreen(new LoginScreen(game));
            }
        });
    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        float screenWidth = Gdx.graphics.getWidth();
        float screenHeight = Gdx.graphics.getHeight();
        float imageWidth = game.backgroundTexture.getWidth();
        float imageHeight = game.backgroundTexture.getHeight();

        Vector2 size = Scaling.fill.apply(imageWidth, imageHeight, screenWidth, screenHeight);
        float x = (screenWidth - size.x) / 2;
        float y = (screenHeight - size.y) / 2;

        game.batch.begin();
        game.batch.draw(game.backgroundTexture, x, y, size.x, size.y);
        game.batch.end();

        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void dispose() {
        stage.dispose();
    }

    @Override
    public void pause() {}
    @Override
    public void resume() {}
    @Override
    public void hide() {}
}
