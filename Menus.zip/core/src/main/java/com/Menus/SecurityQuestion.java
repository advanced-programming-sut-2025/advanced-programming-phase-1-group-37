package com.Menus;// Represents a security question and its answer for a user

import java.util.ArrayList;
import java.util.List;

class SecurityQuestion {
    private int questionNumber; // Corresponds to a predefined list of questions
    private String answer; // Hashed answer for security

    // Default constructor for JSON deserialization
    public SecurityQuestion() {}

    public SecurityQuestion(int questionNumber, String answer) {
        this.questionNumber = questionNumber;
        this.answer = answer; // Store hashed answer
    }

    // Getters and Setters
    public int getQuestionNumber() { return questionNumber; }
    public void setQuestionNumber(int questionNumber) { this.questionNumber = questionNumber; }
    public String getAnswer() { return answer; } // Should be hashed answer
    public void setAnswer(String answer) { this.answer = answer; }

    public static List<String> getQuestionList() {
        List<String> questions = new ArrayList<>();
        questions.add("What was your first pet's name?");
        questions.add("What is your mother's maiden name?");
        questions.add("What city were you born in?");
        // Add more questions as needed
        return questions;
    }
}
