package com.Menus;// Utility for JSON serialization and deserialization using Gson

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

class JsonUtil {
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public static <T> void saveData(List<T> data, String filePath) {
        try (FileWriter writer = new FileWriter(filePath)) {
            gson.toJson(data, writer);
        } catch (IOException e) {
            System.err.println("Error saving data to " + filePath + ": " + e.getMessage());
        }
    }

    public static <T> void saveSingleObject(T data, String filePath) {
        try (FileWriter writer = new FileWriter(filePath)) {
            gson.toJson(data, writer);
        } catch (IOException e) {
            System.err.println("Error saving single object to " + filePath + ": " + e.getMessage());
        }
    }


    public static <T> List<T> loadData(String filePath, Type listType) {
        try (FileReader reader = new FileReader(filePath)) {
            List<T> data = gson.fromJson(reader, listType);
            return data == null ? new ArrayList<>() : data;
        } catch (IOException e) {
            // If file not found, it's not an error for the first run, return empty list.
            // System.err.println("Error loading data from " + filePath + ": " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public static <T> T loadSingleObject(String filePath, Class<T> classOfT) {
        try (FileReader reader = new FileReader(filePath)) {
            return gson.fromJson(reader, classOfT);
        } catch (IOException e) {
            // If file not found, it's not an error for the first run, return null.
            // System.err.println("Error loading single object from " + filePath + ": " + e.getMessage());
            return null;
        }
    }
}
