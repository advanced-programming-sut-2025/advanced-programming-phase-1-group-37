// File: com/Menus/MapSelectionScreen.java
package com.Menus;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Scaling;

public class MapSelectionScreen implements Screen {

    private final StardewGdxGame game;
    private final Stage stage;
    private final Game currentGame;
    private final Label turnLabel;

    public MapSelectionScreen(final StardewGdxGame game, final Game currentGame) {
        this.game = game;
        this.stage = new Stage(new ScreenViewport());
        this.currentGame = currentGame;
        Skin skin = game.skin;

        Table table = new Table();
        table.setFillParent(true);
        table.center();
        stage.addActor(table);

        // --- UI Elements ---
        turnLabel = new Label("", skin, "default");
        updateTurnLabel(); // Set the initial text

        // Create buttons with images for each map
        ImageButton map1Button = new ImageButton(new Image(game.map1Texture).getDrawable());
        ImageButton map2Button = new ImageButton(new Image(game.map2Texture).getDrawable());
        ImageButton map3Button = new ImageButton(new Image(game.map3Texture).getDrawable());
        ImageButton map4Button = new ImageButton(new Image(game.map4Texture).getDrawable());

        // --- Layout ---
        table.add(turnLabel).colspan(4).padBottom(20);
        table.row();
        table.add(map1Button).pad(10);
        table.add(map2Button).pad(10);
        table.add(map3Button).pad(10);
        table.add(map4Button).pad(10);

        // --- Event Listeners ---
        // We'll add a simple listener to each button for now
        map1Button.addListener(createMapSelectionListener(1));
        map2Button.addListener(createMapSelectionListener(2));
        map3Button.addListener(createMapSelectionListener(3));
        map4Button.addListener(createMapSelectionListener(4));
    }

    private void updateTurnLabel() {
        String playerToSelect = currentGame.getCurrentPlayerUsernameForMapSelection();
        if (playerToSelect != null) {
            turnLabel.setText("Player " + playerToSelect + ", please choose your map:");
        } else {
            turnLabel.setText("All maps selected! Starting game...");
            // TODO: Transition to the actual game screen
        }
    }

    private ChangeListener createMapSelectionListener(final int mapNumber) {
        return new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                String currentPlayer = currentGame.getCurrentPlayerUsernameForMapSelection();
                if (currentPlayer != null) {
                    currentGame.getPlayerMapChoices().put(currentPlayer, mapNumber);
                    System.out.println(currentPlayer + " selected map " + mapNumber);

                    // Check if all maps are now selected
                    if (currentGame.getCurrentPlayerUsernameForMapSelection() == null) {
                        currentGame.setAllMapsSelected(true);
                    }

                    game.gameService.saveGame(currentGame); // Save progress
                    updateTurnLabel(); // Update the label for the next player or to show game start
                }
            }
        };
    }

    @Override
    public void show() { Gdx.input.setInputProcessor(stage); }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        float screenWidth = Gdx.graphics.getWidth();
        float screenHeight = Gdx.graphics.getHeight();
        float imageWidth = game.backgroundTexture.getWidth();
        float imageHeight = game.backgroundTexture.getHeight();
        Vector2 size = Scaling.fill.apply(imageWidth, imageHeight, screenWidth, screenHeight);
        float x = (screenWidth - size.x) / 2;
        float y = (screenHeight - size.y) / 2;

        game.batch.begin();
        game.batch.draw(game.backgroundTexture, x, y, size.x, size.y);
        game.batch.end();

        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) { stage.getViewport().update(width, height, true); }
    @Override
    public void dispose() { stage.dispose(); }
    @Override
    public void pause() {}
    @Override
    public void resume() {}
    @Override
    public void hide() {}
}
