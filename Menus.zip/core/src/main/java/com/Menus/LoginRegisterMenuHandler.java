package com.Menus;// Handles commands for the Login/Register menu
// import java.util.Arrays; // Not directly used, but often useful with command parsing
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Scanner;
// import java.util.Random; // UserService handles random suggestions

class LoginRegisterMenuHandler {
    private final UserService userService;
    private final CurrentUserContext currentUserContext;
    private String userForPasswordReset = null; // Stores username during password reset flow
    private String userForSecurityQuestion = null; // Stores username during registration security question flow
    private final Scanner scanner; // Use the shared scanner

    public LoginRegisterMenuHandler(UserService userService, CurrentUserContext currentUserContext, Scanner scanner) {
        this.userService = userService;
        this.currentUserContext = currentUserContext;
        this.scanner = scanner; // Initialize shared scanner
    }

    public void handleCommand(String command) {
        Map<String, String> args = CommandParser.parseArguments(command);
        String baseCommand = CommandParser.getBaseCommand(command);

        if (userForSecurityQuestion != null && baseCommand.equals("pick")) {
            processPickQuestion(args);
            return;
        }

        if (userForPasswordReset != null && baseCommand.equals("answer")) {
            processAnswerSecurityQuestion(args);
            return;
        }


        switch (baseCommand) {
            case "register":
                processRegister(args);
                break;
            case "login":
                processLogin(args);
                break;
            case "forget": // "forget password"
                if (command.startsWith("forget password")) { // ensure it's the full command
                    processForgetPassword(args);
                } else {
                    System.out.println("Error: Unknown command. Did you mean 'forget password -u <username>'?");
                }
                break;
            default:
                System.out.println("Error: Unknown command in Login/Register Menu. Available: register, login, forget password, menu ..., show current menu, exit_program");
        }
    }

    private void processRegister(Map<String, String> args) {
        String username = args.get("u");
        String password = args.get("p");
        String passwordConfirm = args.get("pc"); // Assuming 'pc' for password_confirm from "register -u <username> -p <password> <password_confirm>..."
        String nickname = args.get("n");
        String email = args.get("e");
        String gender = args.get("g");

        if (username == null || password == null || passwordConfirm == null || nickname == null || email == null || gender == null) {
            System.out.println("Error: Missing arguments for register. Usage: register -u <username> -p <password> <password_confirm> -n <nickname> -e <email> -g <gender>");
            return;
        }

        // Handle random password request
        if (password.equalsIgnoreCase("random")) {
            // Scanner scanner = new Scanner(System.in); // Use shared scanner
            String randomPassword = PasswordService.generateRandomPassword();
            System.out.println("Generated random password: " + randomPassword);
            System.out.print("Do you want to use this password? (yes/no): ");
            String choice = scanner.nextLine().trim(); // Use shared scanner
            if (choice.equalsIgnoreCase("yes")) {
                password = randomPassword;
                passwordConfirm = randomPassword; // Confirm is the same
            } else {
                System.out.println("Password generation cancelled. Please enter a password or type 'random' again.");
                return; // Or loop back to ask for password again
            }
        }


        String result = userService.registerUser(username, password, passwordConfirm, nickname, email, gender);
        System.out.println(result);
        if (result.startsWith("User registered successfully")) {
            userForSecurityQuestion = username; // Set context for pick question
            System.out.println("Available security questions:");
            List<String> questions = SecurityQuestion.getQuestionList();
            for (int i = 0; i < questions.size(); i++) {
                System.out.println((i + 1) + ". " + questions.get(i));
            }
            System.out.println("Use: pick question -q <question_number> -a <answer> -c <answer_confirm>");
        }
    }

    private void processPickQuestion(Map<String, String> args) {
        if (userForSecurityQuestion == null) {
            System.out.println("Error: No user context for picking security question. Please register first.");
            return;
        }
        String qNumStr = args.get("q");
        String answer = args.get("a");
        String answerConfirm = args.get("c");

        if (qNumStr == null || answer == null || answerConfirm == null) {
            System.out.println("Error: Missing arguments for pick question. Usage: pick question -q <question_number> -a <answer> -c <answer_confirm>");
            return;
        }
        try {
            int qNum = Integer.parseInt(qNumStr);
            String result = userService.setSecurityQuestionForUser(userForSecurityQuestion, qNum, answer, answerConfirm);
            System.out.println(result);
            if (result.startsWith("Security question set successfully")) {
                userForSecurityQuestion = null; // Clear context
            }
        } catch (NumberFormatException e) {
            System.out.println("Error: Invalid question number format.");
        }
    }


    private void processLogin(Map<String, String> args) {
        String username = args.get("u");
        String password = args.get("p");
        boolean stayLoggedIn = args.containsKey("stay-logged-in");

        if (username == null || password == null) {
            System.out.println("Error: Missing arguments for login. Usage: login -u <username> -p <password> [-stay-logged-in]");
            return;
        }

        String result = userService.loginUser(username, password);
        System.out.println(result);

        if (result.startsWith("Login successful")) {
            Optional<User> userOpt = userService.findUserByUsername(username);
            if (userOpt.isPresent()) {
                currentUserContext.setCurrentUser(userOpt.get());
                currentUserContext.setStayLoggedIn(stayLoggedIn);
                currentUserContext.navigateTo(MenuState.MAIN_MENU);
            } else {
                System.out.println("Error: Could not retrieve user details after login."); // Should not happen
            }
        }
    }

    private void processForgetPassword(Map<String, String> args) {
        String username = args.get("u");
        if (username == null) {
            System.out.println("Error: Missing username for forget password. Usage: forget password -u <username>");
            return;
        }

        Optional<SecurityQuestion> sqOpt = userService.getSecurityQuestionForUser(username);
        if (sqOpt.isPresent()) {
            userForPasswordReset = username;
            int qNum = sqOpt.get().getQuestionNumber();
            System.out.println("Security Question: " + SecurityQuestion.getQuestionList().get(qNum - 1));
            System.out.println("Enter your answer: answer -a <your_answer>");
        } else {
            System.out.println("Error: No security question found for this user or user does not exist.");
            userForPasswordReset = null;
        }
    }

    private void processAnswerSecurityQuestion(Map<String, String> args) {
        if (userForPasswordReset == null) {
            System.out.println("Error: No user context for password reset. Please use 'forget password' first.");
            return;
        }
        String answerArg = args.get("a"); // Renamed to avoid conflict with SecurityQuestion.answer
        if (answerArg == null) {
            System.out.println("Error: Missing answer. Usage: answer -a <your_answer>");
            return;
        }

        if (userService.verifySecurityAnswer(userForPasswordReset, answerArg)) {
            System.out.println("Answer correct. Please enter your new password.");
            // Scanner scanner = new Scanner(System.in); // Use shared scanner
            // This part needs to be integrated into the command loop or handled differently
            // For now, direct input:
            System.out.print("New password: ");
            String newPassword = scanner.nextLine().trim(); // Use shared scanner
            System.out.print("Confirm new password: ");
            String confirmNewPassword = scanner.nextLine().trim(); // Use shared scanner

            if (newPassword.equals(confirmNewPassword)) {
                if (!ValidationUtils.isValidPasswordChars(newPassword)) {
                    System.out.println("Error: New password contains invalid characters.");
                } else if (!PasswordService.isPasswordStrong(newPassword)) {
                    System.out.println("Error: New password is not strong enough.");
                } else {
                    String updateResult = userService.updateUserPassword(userForPasswordReset, newPassword);
                    System.out.println(updateResult);
                }
            } else {
                System.out.println("Error: New passwords do not match.");
            }
        } else {
            System.out.println("Error: Incorrect answer. Returning to Login/Register menu.");
        }
        userForPasswordReset = null; // Clear context
    }
}
