// File: com/Menus/LoginScreen.java
package com.Menus;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Scaling;

public class LoginScreen implements Screen {

    private final StardewGdxGame game;
    private final Stage stage;

    public LoginScreen(final StardewGdxGame game) {
        this.game = game;
        this.stage = new Stage(new ScreenViewport());

        Table table = new Table();
        table.setFillParent(true);
        table.center();
        stage.addActor(table);

        Skin skin = game.skin;

        final Label titleLabel = new Label("Welcome to Stardew Valley", skin, "default");
        final Label messageLabel = new Label("Please log in or register.", skin);
        final TextField usernameField = new TextField("", skin);
        final TextField passwordField = new TextField("", skin);
        passwordField.setPasswordMode(true);
        passwordField.setPasswordCharacter('*');
        final CheckBox stayLoggedInCheckbox = new CheckBox("Stay logged in", skin);
        final TextButton loginButton = new TextButton("Login", skin);
        final TextButton registerButton = new TextButton("Go to Register", skin);

        // *** NEW: Add the "Forgot Password" button ***
        // We use a TextButton but can style it to look like a link later.
        final TextButton forgotPasswordButton = new TextButton("Forgot Password?", skin, "default");

        // --- Layout ---
        table.add(titleLabel).colspan(2).padBottom(40);
        table.row();
        table.add(messageLabel).colspan(2).padBottom(20);
        table.row();
        table.add(new Label("Username:", skin)).left().padRight(10);
        table.add(usernameField).width(250);
        table.row();
        table.add(new Label("Password:", skin)).left().padRight(10);
        table.add(passwordField).width(250).padBottom(10);
        table.row();
        table.add(stayLoggedInCheckbox).colspan(2).padBottom(20);
        table.row();

        // Use a nested table for the login/register buttons
        Table buttonTable = new Table();
        buttonTable.add(loginButton).width(120).padRight(10);
        buttonTable.add(registerButton).width(120);
        table.add(buttonTable).colspan(2).padBottom(10);
        table.row();

        // *** NEW: Add the forgot password button to the layout ***
        table.add(forgotPasswordButton).colspan(2).padTop(10);


        // --- Event Listeners ---
        loginButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                String username = usernameField.getText();
                String password = passwordField.getText();
                boolean stayLoggedIn = stayLoggedInCheckbox.isChecked();
                String result = game.userService.loginUser(username, password);
                if (result.startsWith("Login successful")) {
                    messageLabel.setText(result);
                    game.currentUserContext.setCurrentUser(game.userService.findUserByUsername(username).get());
                    game.currentUserContext.setStayLoggedIn(stayLoggedIn);
                    game.setScreen(new MainMenuScreen(game));
                } else {
                    messageLabel.setText(result);
                }
            }
        });

        registerButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.setScreen(new RegisterScreen(game));
            }
        });

        // *** NEW: Add the listener for the forgot password button ***
        forgotPasswordButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.setScreen(new ForgotPasswordScreen(game));
            }
        });
    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        float screenWidth = Gdx.graphics.getWidth();
        float screenHeight = Gdx.graphics.getHeight();
        float imageWidth = game.backgroundTexture.getWidth();
        float imageHeight = game.backgroundTexture.getHeight();

        Vector2 size = Scaling.fill.apply(imageWidth, imageHeight, screenWidth, screenHeight);
        float x = (screenWidth - size.x) / 2;
        float y = (screenHeight - size.y) / 2;

        game.batch.begin();
        game.batch.draw(game.backgroundTexture, x, y, size.x, size.y);
        game.batch.end();

        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void dispose() {
        stage.dispose();
    }

    @Override
    public void pause() {}
    @Override
    public void resume() {}
    @Override
    public void hide() {}
}
