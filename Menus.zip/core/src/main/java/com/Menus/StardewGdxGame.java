// File: com/Menus/StardewGdxGame.java
package com.Menus;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;

public class StardewGdxGame extends Game {

    // --- Core Services ---
    public UserService userService;
    public GameService gameService;
    public CurrentUserContext currentUserContext;

    // --- UI & Graphics Resources ---
    public Skin skin;
    public SpriteBatch batch;
    public Texture backgroundTexture;

    // *** NEW: Textures for the maps ***
    public Texture map1Texture;
    public Texture map2Texture;
    public Texture map3Texture;
    public Texture map4Texture;
    public Texture[] avatarTextures;


    @Override
    public void create() {
        // --- Initialize Services ---
        userService = new UserService();
        gameService = new GameService(userService);
        currentUserContext = new CurrentUserContext(userService);

        // --- Load UI & Graphics Resources ---
        skin = new Skin(Gdx.files.internal("uiskin.json"));
        batch = new SpriteBatch();
        backgroundTexture = new Texture(Gdx.files.internal("Cloudy Ocean.png"));

        // *** NEW: Load the map textures ***
        map1Texture = new Texture(Gdx.files.internal("map1.jpg"));
        map2Texture = new Texture(Gdx.files.internal("map2.jpg"));
        map3Texture = new Texture(Gdx.files.internal("map3.jpg"));
        map4Texture = new Texture(Gdx.files.internal("map4.jpg"));

        // *** NEW: Load the avatar textures into the array ***
        avatarTextures = new Texture[4];
        for (int i = 0; i < 4; i++) {
            avatarTextures[i] = new Texture(Gdx.files.internal("avatar" + i + ".png"));
        }



        // --- Load Session and Set Initial Screen ---
        currentUserContext.loadSession();
        if (currentUserContext.getCurrentUser() != null) {
            System.out.println("Session loaded for " + currentUserContext.getCurrentUser().getUsername());
            this.setScreen(new MainMenuScreen(this));
        } else {
            System.out.println("No active session found. Please log in.");
            this.setScreen(new LoginScreen(this));
        }
    }

    @Override
    public void dispose() {
        // Dispose of all shared resources
        skin.dispose();
        batch.dispose();
        backgroundTexture.dispose();

        // *** NEW: Dispose of map textures ***
        map1Texture.dispose();
        map2Texture.dispose();
        map3Texture.dispose();
        map4Texture.dispose();

        // *** NEW: Dispose of the avatar textures ***
        for (int i = 0; i < 4; i++) {
            avatarTextures[i].dispose();
        }

        // Save data on exit
        userService.saveUsers();
        gameService.saveGames();
        if (currentUserContext.isStayLoggedIn() && currentUserContext.getCurrentUser() != null) {
            currentUserContext.saveSession();
        } else {
            currentUserContext.clearSession();
        }
    }
}
