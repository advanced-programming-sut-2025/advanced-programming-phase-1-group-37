package com.Menus;// File: com/Menus/User.java

class User {
    private String username;
    private String hashedPassword;
    private String nickname;
    private String email;
    private String gender;
    private SecurityQuestion securityQuestion;
    private int avatarId = 0; // *** NEW: Default to the first avatar (0) ***

    // Statistics
    private double highestMoneyEarned = 0;
    private int gamesPlayed = 0;

    // Default constructor for JSON deserialization
    public User() {}

    public User(String username, String hashedPassword, String nickname, String email, String gender) {
        this.username = username;
        this.hashedPassword = hashedPassword;
        this.nickname = nickname;
        this.email = email;
        this.gender = gender;
    }

    // --- Getters and Setters ---
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getHashedPassword() { return hashedPassword; }
    public void setHashedPassword(String hashedPassword) { this.hashedPassword = hashedPassword; }
    public String getNickname() { return nickname; }
    public void setNickname(String nickname) { this.nickname = nickname; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }
    public SecurityQuestion getSecurityQuestion() { return securityQuestion; }
    public void setSecurityQuestion(SecurityQuestion securityQuestion) { this.securityQuestion = securityQuestion; }

    // *** NEW: Getter and Setter for avatarId ***
    public int getAvatarId() { return avatarId; }
    public void setAvatarId(int avatarId) { this.avatarId = avatarId; }

    public double getHighestMoneyEarned() { return highestMoneyEarned; }
    public void setHighestMoneyEarned(double highestMoneyEarned) { this.highestMoneyEarned = highestMoneyEarned; }
    public int getGamesPlayed() { return gamesPlayed; }
    public void setGamesPlayed(int gamesPlayed) { this.gamesPlayed = gamesPlayed; }

    @Override
    public String toString() {
        return "User{" +
            "username='" + username + '\'' +
            ", nickname='" + nickname + '\'' +
            ", email='" + email + '\'' +
            ", gender='" + gender + '\'' +
            ", highestMoneyEarned=" + highestMoneyEarned +
            ", gamesPlayed=" + gamesPlayed +
            '}';
    }
}
