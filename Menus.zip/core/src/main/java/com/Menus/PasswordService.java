package com.Menus;

// services/PasswordService.java
// Handles password hashing and validation

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;
import java.util.regex.Pattern;

class PasswordService {

    // Basic hashing (replace with SHA-256 for better security as per PDF bonus)
    public static String hashPassword(String password) {
        // IMPORTANT: This is a very basic hash. For production, use a strong algorithm like SHA-256 with salt.
        // Example for SHA-256 (without salt for simplicity here, but salt is crucial):
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashedBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            // Fallback to simple hash if SHA-256 is not available (should not happen in modern JVMs)
            // Or handle more gracefully
            System.err.println("SHA-256 algorithm not found. Using fallback hash (INSECURE): " + e.getMessage());
            return "hashed_" + password;
        }
    }

    public static boolean checkPassword(String rawPassword, String hashedPassword) {
        return hashPassword(rawPassword).equals(hashedPassword);
    }

    public static boolean isPasswordStrong(String password) {
        if (password.length() < 8) return false;
        boolean hasLower = Pattern.compile("[a-z]").matcher(password).find();
        boolean hasUpper = Pattern.compile("[A-Z]").matcher(password).find();
        boolean hasDigit = Pattern.compile("[0-9]").matcher(password).find();
        // As per PDF: $?><,";:\ etc.
        // Corrected Regex: ensures " and \ are properly escaped for Java String literal
        // The characters are: $ ? > < , " ; : \ [ ] { } * + = ( ) ! # % ^ & * - = _ + . ~ ` @
        boolean hasSpecial = Pattern.compile("[\\$\\?\\><,\\\"\\;\\:\\\\\\\\\\[\\]\\{\\}\\*\\+\\=\\(\\)\\!\\#\\%\\^\\&\\*\\-\\=\\_\\+\\.\\~\\`\\@]").matcher(password).find();
        return hasLower && hasUpper && hasDigit && hasSpecial;
    }

    public static String generateRandomPassword() {
        // Generates a strong random password
        String upperCaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String lowerCaseLetters = "abcdefghijklmnopqrstuvwxyz";
        String numbers = "0123456789";
        String specialChars = "$?><,;:*+=%#!"; // Subset from PDF
        String allChars = upperCaseLetters + lowerCaseLetters + numbers + specialChars;

        StringBuilder sb = new StringBuilder();
        Random random = new Random();

        // Ensure at least one of each required type
        sb.append(upperCaseLetters.charAt(random.nextInt(upperCaseLetters.length())));
        sb.append(lowerCaseLetters.charAt(random.nextInt(lowerCaseLetters.length())));
        sb.append(numbers.charAt(random.nextInt(numbers.length())));
        sb.append(specialChars.charAt(random.nextInt(specialChars.length())));

        for (int i = 4; i < 12; i++) { // Generate a password of length 12 for example
            sb.append(allChars.charAt(random.nextInt(allChars.length())));
        }

        // Shuffle the characters
        char[] passwordArray = sb.toString().toCharArray();
        for (int i = 0; i < passwordArray.length; i++) {
            int randomIndex = random.nextInt(passwordArray.length);
            char temp = passwordArray[i];
            passwordArray[i] = passwordArray[randomIndex];
            passwordArray[randomIndex] = temp;
        }
        return new String(passwordArray);
    }
}
