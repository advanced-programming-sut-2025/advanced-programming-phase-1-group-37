// File: com/Menus/GameMenuScreen.java
package com.Menus;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Scaling;

public class GameMenuScreen implements Screen {

    private final StardewGdxGame game;
    private final Stage stage;
    private final Skin skin;
    private final Label messageLabel; // *** NEW: Label for showing messages ***

    public GameMenuScreen(final StardewGdxGame game) {
        this.game = game;
        this.stage = new Stage(new ScreenViewport());
        this.skin = game.skin;

        Table table = new Table();
        table.setFillParent(true);
        table.center();
        stage.addActor(table);

        // --- UI Elements ---
        Label titleLabel = new Label("Game Menu", skin, "default");
        TextButton newGameButton = new TextButton("New Game", skin);
        TextButton loadGameButton = new TextButton("Load Game", skin);
        TextButton backButton = new TextButton("Back to Main Menu", skin);
        messageLabel = new Label("", skin); // Initialize the message label

        // --- Layout ---
        table.add(titleLabel).padBottom(40);
        table.row();
        table.add(newGameButton).width(200).padBottom(10);
        table.row();
        table.add(loadGameButton).width(200).padBottom(10);
        table.row();
        table.add(backButton).width(200).padTop(30);
        table.row();
        table.add(messageLabel).padTop(20); // Add the message label to the layout

        // --- Event Listeners ---
        backButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.setScreen(new MainMenuScreen(game));
            }
        });

        // *** THIS IS THE UPDATED LOGIC FOR THE NEW GAME BUTTON ***
        newGameButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                String currentUsername = game.currentUserContext.getCurrentUser().getUsername();
                // Check if the user is already in a game using your existing service method
                if (game.gameService.isUserInAnySavedGame(currentUsername)) {
                    messageLabel.setText("You are already in a game. Try loading it!");
                } else {
                    // If not in a game, proceed to the setup screen
                    game.setScreen(new NewGameSetupScreen(game));
                }
            }
        });

        // TODO: Add listener for Load Game button.
    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        float screenWidth = Gdx.graphics.getWidth();
        float screenHeight = Gdx.graphics.getHeight();
        float imageWidth = game.backgroundTexture.getWidth();
        float imageHeight = game.backgroundTexture.getHeight();

        Vector2 size = Scaling.fill.apply(imageWidth, imageHeight, screenWidth, screenHeight);
        float x = (screenWidth - size.x) / 2;
        float y = (screenHeight - size.y) / 2;

        game.batch.begin();
        game.batch.draw(game.backgroundTexture, x, y, size.x, size.y);
        game.batch.end();

        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void dispose() {
        stage.dispose();
    }

    @Override
    public void pause() {}
    @Override
    public void resume() {}
    @Override
    public void hide() {}
}
