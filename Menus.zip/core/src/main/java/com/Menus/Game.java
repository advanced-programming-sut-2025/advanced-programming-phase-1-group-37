package com.Menus;// models/Game.java
// Represents a game instance

import java.util.*;


class Game {
    private String gameId;
    private String mainPlayerUsername; // User who created or last loaded the game
    private List<String> playerUsernames; // All players in the game
    private Map<String, Integer> playerMapChoices; // Username -> Map Number
    private int currentPlayerTurnIndex;
    private boolean allMapsSelected;
    // Add other game state variables: date, time, weather, items, farm data, etc.

    // Default constructor for JSON deserialization
    public Game() {
        this.playerUsernames = new ArrayList<>();
        this.playerMapChoices = new HashMap<>();
        this.gameId = UUID.randomUUID().toString(); // Unique ID for each game
    }

    public Game(String mainPlayerUsername, List<String> invitedPlayerUsernames) {
        this();
        this.mainPlayerUsername = mainPlayerUsername;
        this.playerUsernames.add(mainPlayerUsername);
        if (invitedPlayerUsernames != null) { // Add null check for safety
            this.playerUsernames.addAll(invitedPlayerUsernames);
        }
        this.currentPlayerTurnIndex = 0; // Main player starts
        this.allMapsSelected = false;
    }

    // Getters and Setters
    public String getGameId() { return gameId; }
    public void setGameId(String gameId) { this.gameId = gameId; } // For JSON if needed
    public String getMainPlayerUsername() { return mainPlayerUsername; }
    public void setMainPlayerUsername(String mainPlayerUsername) { this.mainPlayerUsername = mainPlayerUsername; }
    public List<String> getPlayerUsernames() { return playerUsernames; }
    public void setPlayerUsernames(List<String> playerUsernames) { this.playerUsernames = playerUsernames; }
    public Map<String, Integer> getPlayerMapChoices() { return playerMapChoices; }
    public void setPlayerMapChoices(Map<String, Integer> playerMapChoices) { this.playerMapChoices = playerMapChoices; }
    public int getCurrentPlayerTurnIndex() { return currentPlayerTurnIndex; }
    public void setCurrentPlayerTurnIndex(int currentPlayerTurnIndex) { this.currentPlayerTurnIndex = currentPlayerTurnIndex; }
    public boolean areAllMapsSelected() { return allMapsSelected; }
    public void setAllMapsSelected(boolean allMapsSelected) { this.allMapsSelected = allMapsSelected; }


    public String getCurrentPlayerUsernameForMapSelection() {
        if (allMapsSelected) return null;
        for (String username : playerUsernames) {
            if (!playerMapChoices.containsKey(username)) {
                return username;
            }
        }
        // If loop finishes, all maps should have been selected
        allMapsSelected = true;
        return null;
    }

    public String getCurrentPlayerForTurn() {
        if (playerUsernames.isEmpty() || currentPlayerTurnIndex < 0 || currentPlayerTurnIndex >= playerUsernames.size()) {
            return null; // Or handle error
        }
        return playerUsernames.get(currentPlayerTurnIndex);
    }

    public void nextTurn() {
        if (playerUsernames.isEmpty()) return; // Avoid issues if no players
        currentPlayerTurnIndex = (currentPlayerTurnIndex + 1) % playerUsernames.size();
        // If currentPlayerTurnIndex becomes 0, a full round has passed.
        // This is where game time would advance by 1 hour as per PDF.
        if (currentPlayerTurnIndex == 0) {
            System.out.println("A full round of turns has passed. Game time advances by 1 hour (not implemented yet).");
            // TODO: Implement time advancement
        }
    }

    public boolean isPlayerInGame(String username) {
        return playerUsernames.contains(username);
    }
}
