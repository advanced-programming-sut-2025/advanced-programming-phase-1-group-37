package com.Menus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class CommandParser {

    // Pattern to identify a token that is a flag (e.g., -f, -flag)
    // A flag starts with "-" followed by one or more alphanumeric characters or hyphens.
    private static final Pattern FLAG_IDENTIFIER_PATTERN = Pattern.compile("^-([a-zA-Z0-9\\-]+)$");

    // Regex to tokenize an argument string:
    // It captures either:
    // 1. A sequence of characters enclosed in double quotes (group 1 captures content inside quotes).
    // OR
    // 2. A sequence of non-whitespace characters (group 2).
    private static final Pattern ARGUMENT_TOKENIZER_PATTERN = Pattern.compile("\"([^\"]*)\"|(\\S+)");

    /**
     * Extracts the base command keyword from the input string.
     * It prioritizes known multi-word commands to determine the logical base.
     * For example, "game new" would be routed based on "game".
     *
     * @param input The full command string.
     * @return The base command keyword (e.g., "game", "register", "menu").
     */
    public static String getBaseCommand(String input) {
        if (input == null || input.isEmpty()) {
            return "";
        }
        String trimmedInput = input.trim();

        // Known multi-word commands that map to specific base handlers.
        // Order can matter if commands are prefixes of others, though current logic handles it.
        if (trimmedInput.startsWith("forget password")) return "forget";
        if (trimmedInput.startsWith("pick question")) return "pick";
        if (trimmedInput.startsWith("game new")) return "game";
        if (trimmedInput.startsWith("game map")) return "game";
        if (trimmedInput.startsWith("user logout")) return "user";
        if (trimmedInput.startsWith("user info")) return "user";
        if (trimmedInput.startsWith("next turn")) return "next";
        if (trimmedInput.startsWith("exit game")) return "exit";
        if (trimmedInput.startsWith("load game")) return "load";
        if (trimmedInput.startsWith("menu enter")) return "menu";
        if (trimmedInput.startsWith("menu exit")) return "menu";
        if (trimmedInput.startsWith("show current menu")) return "show";
        // Add other specific multi-word command prefixes here if they map to a unique base.

        // If no specific multi-word command is matched, take the first word as the base.
        String[] parts = trimmedInput.split("\\s+", 2);
        return parts[0];
    }

    /**
     * Parses the input string to extract arguments as flag-value pairs.
     * Handles flags with single or multiple values (unquoted values are space-separated,
     * quoted values are treated as a single value).
     *
     * @param fullInput The full command string entered by the user.
     * @return A map where keys are flag names (without "-") and values are the
     * corresponding argument strings. Boolean flags (flags with no subsequent values
     * before the next flag or end of input) are stored with the value "true".
     * Also includes a "_full_command_" key with the original input string.
     * Unflagged tokens at the start of the argument string are collected under "_unflagged_args_".
     */
    public static Map<String, String> parseArguments(String fullInput) {
        Map<String, String> args = new HashMap<>();
        args.put("_full_command_", fullInput); // Store the full command for context

        if (fullInput == null || fullInput.isEmpty()) {
            return args;
        }

        String commandToParse = fullInput.trim();
        String argumentsString = "";

        // --- Isolate the argument string ---
        // This section attempts to remove the command phrase (e.g., "game new", "register")
        // to get only the part of the string that contains flags and their values.
        String[] knownCommandPhrases = {
                "forget password", "pick question", "game new", "game map",
                "user logout", "user info", "next turn", "exit game", "load game",
                "menu enter", "menu exit", "show current menu"
                // Add any other multi-word command phrases that should be stripped.
        };

        String actualCommandPhrase = "";
        for (String phrase : knownCommandPhrases) {
            // Check if the input starts with the known command phrase followed by a space,
            // or if the input is exactly the command phrase (i.e., no arguments).
            if (commandToParse.startsWith(phrase + " ") || commandToParse.equals(phrase)) {
                if (phrase.length() > actualCommandPhrase.length()) { // Prefer the longest match
                    actualCommandPhrase = phrase;
                }
            }
        }

        if (actualCommandPhrase.isEmpty()) {
            // If no multi-word phrase matched, assume the command is the first word.
            String[] parts = commandToParse.split("\\s+", 2);
            if (parts.length > 0) {
                actualCommandPhrase = parts[0];
            } else { // Should not happen if fullInput was not empty and trimmed
                return args;
            }
        }

        // Get the substring that contains only the arguments
        if (commandToParse.length() > actualCommandPhrase.length()) {
            argumentsString = commandToParse.substring(actualCommandPhrase.length()).trim();
        } else {
            argumentsString = ""; // No arguments after the command phrase
        }
        // --- End of argument string isolation ---

        if (argumentsString.isEmpty()) {
            // No arguments to parse for flags.
            return args;
        }

        // Tokenize the argumentsString respecting quotes
        List<String> tokens = new ArrayList<>();
        Matcher tokenMatcher = ARGUMENT_TOKENIZER_PATTERN.matcher(argumentsString);
        while (tokenMatcher.find()) {
            if (tokenMatcher.group(1) != null) { // Group 1 is for quoted tokens (content inside quotes)
                tokens.add(tokenMatcher.group(1));
            } else { // Group 2 is for unquoted, non-whitespace sequences
                tokens.add(tokenMatcher.group(2));
            }
        }

        String currentFlag = null; // Holds the name of the flag currently being processed
        List<String> valueCollector = new ArrayList<>(); // Collects values for the currentFlag

        for (String token : tokens) {
            Matcher flagMatcher = FLAG_IDENTIFIER_PATTERN.matcher(token);
            if (flagMatcher.matches()) { // Current token is a flag (e.g., "-u", "-my-flag")
                // If a previous flag (currentFlag) was being processed, store its collected values.
                if (currentFlag != null) {
                    if (valueCollector.isEmpty()) {
                        args.put(currentFlag, "true"); // Previous flag was boolean (no values followed)
                    } else {
                        args.put(currentFlag, String.join(" ", valueCollector)); // Join collected values with space
                    }
                }
                currentFlag = flagMatcher.group(1); // Set new currentFlag (name without "-")
                valueCollector.clear(); // Clear collector for the new flag's values
            } else if (currentFlag != null) { // Current token is a value for the active currentFlag
                valueCollector.add(token);
            } else {
                // Token is not a flag and no flag is currently active.
                // This means it's an unflagged argument at the beginning of the argument string.
                // These are collected under a special key.
                // Using computeIfAbsent to initialize the list if it's the first unflagged arg.
                // And then joining them with spaces if multiple unflagged args are present.
                // This is a simplification for Map<String, String>. A List<String> would be cleaner for _unflagged_args_.
                String existingUnflagged = args.get("_unflagged_args_");
                if (existingUnflagged == null) {
                    args.put("_unflagged_args_", token);
                } else {
                    args.put("_unflagged_args_", existingUnflagged + " " + token);
                }
            }
        }

        // After the loop, store the last processed flag and its values
        if (currentFlag != null) {
            if (valueCollector.isEmpty()) {
                args.put(currentFlag, "true"); // Last flag was boolean
            } else {
                args.put(currentFlag, String.join(" ", valueCollector));
            }
        }

        // Special handling for "game map <number>" where number is an implicit argument.
        // This can be useful if the GameMenuHandler relies on this specific key.
        if (fullInput.matches("game map \\d+")) {
            String[] parts = fullInput.split("\\s+");
            if (parts.length == 3) { // "game", "map", "number"
                args.put("map_number_implicit", parts[2]);
            }
        }

        // Regarding "register -u <username> -p <password> <password_confirm> ...":
        // If <password_confirm> is positional, the LoginRegisterMenuHandler needs to parse
        // the value obtained for the "-p" flag. For example, if args.get("p") is "pass pass_confirm",
        // the handler should split this.
        // The current parser will group multiple non-flag tokens after a flag into that flag's value.
        // If `LoginRegisterMenuHandler` expects `args.get("pc")`, then `-pc` must be used as a flag.

        return args;
    }
}
