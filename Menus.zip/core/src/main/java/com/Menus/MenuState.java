package com.Menus;

// MenuState.java
// Enum to represent different menu states in the game
enum MenuState {
    LOGIN_REGISTER,
    MAIN_MENU,
    PROFILE_MENU,
    GAME_MENU,
    GAME_MAP_SELECTION, // Sub-state of GAME_MENU for map selection phase
    IN_GAME // Represents when the player is actively in a game session
}
