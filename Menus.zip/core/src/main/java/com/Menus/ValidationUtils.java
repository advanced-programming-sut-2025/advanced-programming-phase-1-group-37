package com.Menus;// Utility class for input validation
import java.util.regex.Pattern;

class ValidationUtils {
    // Username: letters, numbers, hyphen
    private static final Pattern USERNAME_PATTERN = Pattern.compile("^[a-zA-Z0-9-]+$");
    // Email validation (simplified based on PDF rules)
    // user part: a-zA-Z0-9._- , not start/end with ., no ..
    // domain part: a-zA-Z0-9.- , at least one ., TLD min 2 chars, not start/end with .
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
            "^(?=.{1,64}@)[A-Za-z0-9]+(?:[._-][A-Za-z0-9]+)*@" +
                    "(?:[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?\\.)+[A-Za-z]{2,}$");


    public static boolean isValidUsername(String username) {
        if (username == null || username.isEmpty()) return false;
        return USERNAME_PATTERN.matcher(username).matches();
        // PDF: "نام کاربری تنها میتواند شامل حروف کوچک و بزرگ، اعداد و نماد - باشد."
        // PDF also states max 8 chars for register, but this is not mentioned in "invalid username" error.
        // This check is for the format. Length check can be separate.
    }

    public static boolean isValidEmail(String email) {
        if (email == null || email.isEmpty()) return false;

        // Rule 1: Must contain one and only one '@'
        if (email.chars().filter(ch -> ch == '@').count() != 1) return false;

        String[] parts = email.split("@");
        if (parts.length != 2) return false; // Should be handled by previous check, but good for safety

        String localPart = parts[0];
        String domainPart = parts[1];

        // Local part validation
        // Rule 2a: Only English letters (A-Za-z), numbers (0-9), dot (.), hyphen (-), underscore (_)
        if (!Pattern.matches("^[A-Za-z0-9._-]+$", localPart)) return false;
        // Rule 2b: Start and end with a letter or number
        if (!Pattern.matches("^[A-Za-z0-9].*", localPart) || !Pattern.matches(".*[A-Za-z0-9]$", localPart)) return false;
        // Rule 2c: Dot (.) should not be consecutive
        if (localPart.contains("..")) return false;

        // Domain part validation
        // Rule 3a: Must contain at least one dot (.)
        if (!domainPart.contains(".")) return false;
        // Rule 3b: TLD (e.g., .com, .org) must be at least two characters long
        String[] domainSubParts = domainPart.split("\\.");
        if (domainSubParts.length < 2 || domainSubParts[domainSubParts.length - 1].length() < 2) return false;
        // Rule 3c: Only English letters, numbers (0-9), hyphen (-)
        if (!Pattern.matches("^[A-Za-z0-9.-]+$", domainPart)) return false;
        // Rule 3d: Start and end with a letter or number
        if (!Pattern.matches("^[A-Za-z0-9].*", domainPart) || !Pattern.matches(".*[A-Za-z0-9]$", domainPart)) return false;
        // Rule 3e: No forbidden symbols (already covered by character set check)

        // Additional check for domain parts not starting/ending with hyphen (implied by start/end with letter/number for the whole domain)
        for (String subPart : domainSubParts) {
            if (subPart.startsWith("-") || subPart.endsWith("-")) return false;
        }
        // Check for double dots in domain (e.g., domain..com)
        if (domainPart.contains("..")) return false;


        return EMAIL_PATTERN.matcher(email).matches(); // General regex check as well
    }

    public static boolean isValidPasswordChars(String password) {
        // PDF: "در رمز عبور تنها مجاز به استفاده از نمادهای خاص اعداد و حروف کوچک و بزرگ هستیم."
        // This means no other characters like spaces, tabs etc.
        // The special characters are defined as: $?><,";:\\[]{}*+=()!#%^&*-=_.`~@
        // We can check if the password contains ONLY allowed characters.
        // Corrected Regex: ensures " and \ are properly escaped for Java String literal
        return Pattern.matches("^[a-zA-Z0-9\\$\\?\\><,\\\"\\;\\:\\\\\\\\\\[\\]\\{\\}\\*\\+\\=\\(\\)\\!\\#\\%\\^\\&\\*\\-\\=\\_\\+\\.\\~\\`\\@]+$", password);
    }
}
