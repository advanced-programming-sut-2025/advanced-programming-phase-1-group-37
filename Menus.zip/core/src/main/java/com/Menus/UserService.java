package com.Menus;// Manages user data, registration, login, and persistence

import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;


class UserService {
    private List<User> users;
    private static final String USERS_FILE_PATH = "users.json";

    public UserService() {
        this.users = new ArrayList<>();
        loadUsers();
    }

    public void loadUsers() {
        Type userListType = new TypeToken<ArrayList<User>>() {}.getType();
        this.users = JsonUtil.loadData(USERS_FILE_PATH, userListType);
        if (this.users == null) {
            this.users = new ArrayList<>();
        }
    }

    public void saveUsers() {
        JsonUtil.saveData(users, USERS_FILE_PATH);
    }

    public Optional<User> findUserByUsername(String username) {
        return users.stream().filter(u -> u.getUsername().equals(username)).findFirst();
    }

    public String registerUser(String username, String password, String passwordConfirm, String nickname, String email, String gender) {
        // Username validation (length, characters)
        if (!ValidationUtils.isValidUsername(username)) {
            return "Error: Invalid username format. Use letters, numbers, and hyphens only.";
        }
        if (username.length() > 8) { // As per "register -u username -p password -e email" example in PDF (page 10)
            return "Error: Username cannot be longer than 8 characters.";
        }
        if (findUserByUsername(username).isPresent()) {
            // Suggest new usernames
            String suggestedUsername1 = username + new Random().nextInt(100);
            String suggestedUsername2 = username + "-alt";
            return "Error: Username already exists. Suggestions: " + suggestedUsername1 + ", " + suggestedUsername2 + ". Or try another.";
        }

        // Email validation
        if (!ValidationUtils.isValidEmail(email)) {
            return "Error: Invalid email format.";
        }

        // Password validation
        if (!ValidationUtils.isValidPasswordChars(password)) {
            return "Error: Password contains invalid characters.";
        }
        if (!PasswordService.isPasswordStrong(password)) {
            // Provide reasons for weak password based on PasswordService.isPasswordStrong logic
            String reason = "Password is weak. It must be at least 8 characters long, include uppercase, lowercase, numbers, and special symbols.";
            // TODO: Detail the exact missing criteria
            return "Error: " + reason;
        }
        if (!password.equals(passwordConfirm)) {
            return "Error: Passwords do not match. Please re-enter or return to registration menu.";
        }

        String hashedPassword = PasswordService.hashPassword(password);
        User newUser = new User(username, hashedPassword, nickname, email, gender);
        users.add(newUser);
        saveUsers();
        return "User registered successfully. Please pick a security question.";
    }

    public String setSecurityQuestionForUser(String username, int questionNumber, String answer, String answerConfirm) {
        Optional<User> userOpt = findUserByUsername(username);
        if (!userOpt.isPresent()) {
            return "Error: User not found for setting security question.";
        }
        if (questionNumber < 1 || questionNumber > SecurityQuestion.getQuestionList().size()) {
            return "Error: Invalid question number.";
        }
        if (answer == null || answer.isEmpty() || !answer.equals(answerConfirm)) {
            return "Error: Answers do not match or are empty.";
        }

        User user = userOpt.get();
        // IMPORTANT: Hash the security answer before storing
        String hashedAnswer = PasswordService.hashPassword(answer); // Use the same hashing as passwords
        user.setSecurityQuestion(new SecurityQuestion(questionNumber, hashedAnswer));
        saveUsers();
        return "Security question set successfully for " + username + ".";
    }

    public String loginUser(String username, String password) {
        Optional<User> userOpt = findUserByUsername(username);
        if (!userOpt.isPresent()) {
            return "Error: Username not found.";
        }
        User user = userOpt.get();
        if (!PasswordService.checkPassword(password, user.getHashedPassword())) {
            return "Error: Incorrect password.";
        }
        // Login successful
        return "Login successful. Welcome, " + user.getNickname() + "!";
    }

    public Optional<SecurityQuestion> getSecurityQuestionForUser(String username) {
        Optional<User> userOpt = findUserByUsername(username);
        if (userOpt.isPresent() && userOpt.get().getSecurityQuestion() != null) {
            return Optional.of(userOpt.get().getSecurityQuestion());
        }
        return Optional.empty();
    }

    public boolean verifySecurityAnswer(String username, String answer) {
        Optional<User> userOpt = findUserByUsername(username);
        if (userOpt.isPresent() && userOpt.get().getSecurityQuestion() != null) {
            String hashedAnswerAttempt = PasswordService.hashPassword(answer);
            return hashedAnswerAttempt.equals(userOpt.get().getSecurityQuestion().getAnswer());
        }
        return false;
    }

    public String updateUserPassword(String username, String newPassword) {
        Optional<User> userOpt = findUserByUsername(username);
        if (!userOpt.isPresent()) {
            return "Error: User not found.";
        }
        if (!ValidationUtils.isValidPasswordChars(newPassword)) {
            return "Error: New password contains invalid characters.";
        }
        if (!PasswordService.isPasswordStrong(newPassword)) {
            return "Error: New password is not strong enough.";
        }
        userOpt.get().setHashedPassword(PasswordService.hashPassword(newPassword));
        saveUsers();
        return "Password updated successfully for " + username + ".";
    }

    public String changeUsername(User currentUser, String newUsername) {
        if (newUsername.equals(currentUser.getUsername())) {
            return "Error: New username is the same as the current one.";
        }
        if (!ValidationUtils.isValidUsername(newUsername)) {
            return "Error: Invalid new username format.";
        }
        if (newUsername.length() > 8) {
            return "Error: New username cannot be longer than 8 characters.";
        }
        if (findUserByUsername(newUsername).isPresent()) {
            return "Error: New username already taken.";
        }
        // Update username in all games if this user is a participant
        // This part is complex and depends on how games store player identifiers.
        // For now, just update the user object.
        currentUser.setUsername(newUsername); // This changes the key if map uses username.
        // Better to have a persistent User ID.
        saveUsers(); // Need to re-save all users.
        return "Username changed successfully to " + newUsername + ".";
    }

    public String changeNickname(User currentUser, String newNickname) {
        if (newNickname.equals(currentUser.getNickname())) {
            return "Error: New nickname is the same as the current one.";
        }
        currentUser.setNickname(newNickname);
        saveUsers();
        return "Nickname changed successfully to " + newNickname + ".";
    }

    public String changeEmail(User currentUser, String newEmail) {
        if (newEmail.equals(currentUser.getEmail())) {
            return "Error: New email is the same as the current one.";
        }
        if (!ValidationUtils.isValidEmail(newEmail)) {
            return "Error: Invalid new email format.";
        }
        currentUser.setEmail(newEmail);
        saveUsers();
        return "Email changed successfully to " + newEmail + ".";
    }

    public String changePassword(User currentUser, String oldPassword, String newPassword) {
        if (!PasswordService.checkPassword(oldPassword, currentUser.getHashedPassword())) {
            return "Error: Incorrect old password.";
        }
        if (PasswordService.checkPassword(newPassword, currentUser.getHashedPassword())) {
            return "Error: New password is the same as the current one.";
        }
        if (!ValidationUtils.isValidPasswordChars(newPassword)) {
            return "Error: New password contains invalid characters.";
        }
        if (!PasswordService.isPasswordStrong(newPassword)) {
            return "Error: New password is not strong enough.";
        }
        currentUser.setHashedPassword(PasswordService.hashPassword(newPassword));
        saveUsers();
        return "Password changed successfully.";
    }

    public void changeAvatar(User currentUser, int avatarId) {
        if (avatarId >= 0 && avatarId <= 3) { // Simple validation
            currentUser.setAvatarId(avatarId);
            saveUsers(); // Save the change to the users.json file
        }
    }
}
