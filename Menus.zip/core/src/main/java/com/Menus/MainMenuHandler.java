package com.Menus;// Handles commands for the Main Menu

class MainMenuHandler {
    private final CurrentUserContext currentUserContext;

    public MainMenuHandler(CurrentUserContext currentUserContext) {
        this.currentUserContext = currentUserContext;
    }

    public void handleCommand(String command) {
        String baseCommand = CommandParser.getBaseCommand(command);
        // Args not strictly needed for current main menu commands but good for consistency
        // Map<String, String> args = CommandParser.parseArguments(command);

        if (currentUserContext.getCurrentUser() == null) {
            System.out.println("Error: No user logged in. Redirecting to Login/Register menu.");
            currentUserContext.navigateTo(MenuState.LOGIN_REGISTER);
            return;
        }

        switch (baseCommand) {
            case "user": // "user logout"
                if (command.equalsIgnoreCase("user logout")) {
                    currentUserContext.logout();
                } else {
                    System.out.println("Error: Unknown user command. Did you mean 'user logout'?");
                }
                break;
            // Navigation to Profile or Game menu is handled by "menu enter <menu_name>" in StardewCLI
            default:
                System.out.println("Error: Unknown command in Main Menu. Available: user logout, menu enter profile, menu enter game, menu exit, show current menu, exit_program");
        }
    }
}
