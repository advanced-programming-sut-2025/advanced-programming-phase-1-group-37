    package com.Menus;
    import java.util.Scanner;

    public class StardewCLI {
        private static final Scanner scanner = new Scanner(System.in);
        private static final UserService userService = new UserService();
        private static final GameService gameService = new GameService(userService);
        // Initialize CurrentUserContext with userService. Session loading will happen within its methods.
        private static final CurrentUserContext currentUserContext = new CurrentUserContext(userService);

        private static final LoginRegisterMenuHandler loginRegisterMenuHandler = new LoginRegisterMenuHandler(userService, currentUserContext, scanner);
        private static final MainMenuHandler mainMenuHandler = new MainMenuHandler(currentUserContext);
        private static final ProfileMenuHandler profileMenuHandler = new ProfileMenuHandler(currentUserContext, userService);
        private static final GameMenuHandler gameMenuHandler = new GameMenuHandler(currentUserContext, gameService, userService);

        public static void main(String[] args) {
            System.out.println("Welcome to Stardew Valley CLI!");

            // Load all necessary data at the beginning
            userService.loadUsers();
            gameService.loadGames();
            currentUserContext.loadSession(); // Attempt to load a saved session and set currentUser and stayLoggedIn status

            // Determine initial menu based on whether a session was successfully loaded
            if (currentUserContext.getCurrentUser() != null) {
                System.out.println("Automatically logged in as: " + currentUserContext.getCurrentUser().getUsername());
                currentUserContext.setCurrentMenu(MenuState.MAIN_MENU); // Go to main menu if session loaded
            } else {
                currentUserContext.setCurrentMenu(MenuState.LOGIN_REGISTER); // Otherwise, start at login/register
            }

            displayMenuPrompt();

            while (true) {
                System.out.print("> ");
                String command = scanner.nextLine().trim();

                if (command.equalsIgnoreCase("exit_program")) {
                    System.out.println("Exiting Stardew Valley CLI. Goodbye!");

                    // Save all data before exiting
                    userService.saveUsers();
                    gameService.saveGames();

                    // Session saving logic:
                    // Save session if user is logged in AND they opted to stay logged in.
                    if (currentUserContext.isStayLoggedIn() && currentUserContext.getCurrentUser() != null) {
                        currentUserContext.saveSession();
                    } else {
                        // Otherwise, clear any existing session file (e.g., if user logged out, or didn't opt to stay logged in).
                        currentUserContext.clearSession();
                    }
                    break; // Exit the main loop
                }

                processCommand(command);

                // Avoid double prompt if the command was exit_program (though loop breaks before this)
                // This check is more for robustness in case of future changes.
                if (!command.equalsIgnoreCase("exit_program")) {
                    displayMenuPrompt();
                }
            }
            scanner.close();
        }

        private static void processCommand(String command) {
            // General menu commands that should be available regardless of the specific menu context (within limits)
            if (command.startsWith("menu enter ")) {
                String menuToEnterStr = command.substring("menu enter ".length()).trim().toUpperCase();
                try {
                    MenuState menuToEnter = MenuState.valueOf(menuToEnterStr);
                    currentUserContext.navigateTo(menuToEnter);
                } catch (IllegalArgumentException e) {
                    System.out.println("Error: Invalid menu name '" + menuToEnterStr + "'.");
                }
                return;
            }
            if (command.equalsIgnoreCase("menu exit")) {
                currentUserContext.exitMenu();
                return;
            }
            if (command.equalsIgnoreCase("show current menu")) {
                System.out.println("Current menu: " + currentUserContext.getCurrentMenu());
                return;
            }

            // Delegate command to the handler for the current menu
            switch (currentUserContext.getCurrentMenu()) {
                case LOGIN_REGISTER:
                    loginRegisterMenuHandler.handleCommand(command);
                    break;
                case MAIN_MENU:
                    mainMenuHandler.handleCommand(command);
                    break;
                case PROFILE_MENU:
                    profileMenuHandler.handleCommand(command);
                    break;
                case GAME_MENU:
                case GAME_MAP_SELECTION:
                case IN_GAME:
                    gameMenuHandler.handleCommand(command);
                    break;
                default:
                    System.out.println("Error: Unknown or unhandled menu state: " + currentUserContext.getCurrentMenu());
            }
        }

        private static void displayMenuPrompt() {
            System.out.println("--- You are in " + currentUserContext.getCurrentMenu() + " ---");
            // Consider adding a helper method to display available commands based on the current menu
            // e.g., showAvailableCommands(currentUserContext.getCurrentMenu());
        }
    }
