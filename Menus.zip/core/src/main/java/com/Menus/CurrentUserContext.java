package com.Menus;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Optional; // Required for Optional

class CurrentUserContext {
    private User currentUser;
    private MenuState currentMenu;
    private Game currentGame; // Current active game
    private boolean stayLoggedIn = false; // Default to false
    private UserService userService;

    private static final String SESSION_FILE_PATH = "session.txt";

    public CurrentUserContext(UserService userService) {
        this.currentMenu = MenuState.LOGIN_REGISTER;
        this.userService = userService;
        // currentUser is initially null
        // stayLoggedIn is initially false
    }

    public User getCurrentUser() { return currentUser; }
    public void setCurrentUser(User user) { this.currentUser = user; }
    public MenuState getCurrentMenu() { return currentMenu; }
    public void setCurrentMenu(MenuState menu) { this.currentMenu = menu; }
    public Game getCurrentGame() { return currentGame; }
    public void setCurrentGame(Game game) { this.currentGame = game; }
    public boolean isStayLoggedIn() { return stayLoggedIn; }
    public void setStayLoggedIn(boolean stayLoggedIn) {
        this.stayLoggedIn = stayLoggedIn;
        // System.out.println("Debug: stayLoggedIn set to " + this.stayLoggedIn); // Optional debug line
    }

    public void logout() {
        this.currentUser = null;
        this.currentGame = null;
        this.stayLoggedIn = false; // Important: clear stayLoggedIn on explicit logout
        clearSession();
        setCurrentMenu(MenuState.LOGIN_REGISTER);
        System.out.println("User logged out successfully.");
    }

    public void saveSession() {
        if (currentUser != null && stayLoggedIn) {
            try (FileWriter writer = new FileWriter(SESSION_FILE_PATH)) {
                writer.write(currentUser.getUsername());
                // System.out.println("Debug: Session saved for " + currentUser.getUsername()); // Optional debug line
            } catch (IOException e) {
                System.err.println("Error saving session: " + e.getMessage());
            }
        } else {
            // If for some reason saveSession is called when it shouldn't, ensure session is cleared.
            // This case should ideally be handled by the caller (StardewCLI's exit logic)
            // System.out.println("Debug: Save session skipped or cleared. User: " + (currentUser != null) + ", StayLoggedIn: " + stayLoggedIn); // Optional debug line
            // clearSession(); // Re-evaluate if clearSession() should be here or solely in StardewCLI's else branch
        }
    }

    public void loadSession() {
        boolean sessionSuccessfullyLoaded = false;
        try {
            File sessionFile = new File(SESSION_FILE_PATH);
            if (sessionFile.exists() && sessionFile.length() > 0) { // Check if file exists and is not empty
                String username = new String(Files.readAllBytes(Paths.get(SESSION_FILE_PATH))).trim();
                if (username != null && !username.isEmpty()) { // Check if username read is not null or empty
                    Optional<User> userOpt = userService.findUserByUsername(username);
                    if (userOpt.isPresent()) {
                        this.currentUser = userOpt.get();
                        this.stayLoggedIn = true; // Session loaded, user intended to stay logged in.
                        sessionSuccessfullyLoaded = true;
                        // System.out.println("Debug: Session loaded for " + username + ". stayLoggedIn is now true.");
                    } else {
                        // User from session file exists but user is not in the main user database.
                        System.err.println("User '" + username + "' from session file not found in user database. Clearing session.");
                    }
                } else {
                    // Session file exists but username is empty (e.g. file with only whitespace).
                    System.err.println("Session file contains an empty username. Clearing session.");
                }
            }
            // If sessionFile does not exist or is empty, sessionSuccessfullyLoaded remains false.
        } catch (IOException e) {
            System.err.println("Error loading session: " + e.getMessage());
            // sessionSuccessfullyLoaded remains false.
        }

        if (!sessionSuccessfullyLoaded) {
            // If session was not successfully loaded for any reason (file not found, empty, user not in DB, IO error),
            // ensure currentUser is null, stayLoggedIn is false, and clear any potentially corrupt/stale session file.
            this.currentUser = null;
            this.stayLoggedIn = false;
            // System.out.println("Debug: Session not loaded or failed. stayLoggedIn is now false.");
            File sessionFile = new File(SESSION_FILE_PATH);
            if (sessionFile.exists()) { // Only attempt to delete if it exists
                clearSession(); // Clear the problematic session file
            }
        }
    }

    public void clearSession() {
        try {
            Files.deleteIfExists(Paths.get(SESSION_FILE_PATH));
            // System.out.println("Debug: Session file cleared."); // Optional debug line
        } catch (IOException e) {
            System.err.println("Error clearing session file: " + e.getMessage());
        }
    }

    // Menu navigation logic
    public void navigateTo(MenuState targetMenu) {
        boolean allowed = false;
        // Allow navigation to the same menu
        if (targetMenu == currentMenu) {
            allowed = true;
        } else {
            switch (currentMenu) {
                case LOGIN_REGISTER:
                    if (targetMenu == MenuState.MAIN_MENU && currentUser != null) allowed = true;
                        // Allow going from LOGIN_REGISTER to LOGIN_REGISTER (e.g. after failed login to try again)
                    else if (targetMenu == MenuState.LOGIN_REGISTER) allowed = true;
                    break;
                case MAIN_MENU:
                    if (targetMenu == MenuState.PROFILE_MENU || targetMenu == MenuState.GAME_MENU) allowed = true;
                    break;
                case PROFILE_MENU:
                    if (targetMenu == MenuState.MAIN_MENU) allowed = true;
                    break;
                case GAME_MENU:
                    // From GAME_MENU, can go to MAIN_MENU (exit game context), MAP_SELECTION (new game), or IN_GAME (load game)
                    if (targetMenu == MenuState.MAIN_MENU || targetMenu == MenuState.GAME_MAP_SELECTION || targetMenu == MenuState.IN_GAME) allowed = true;
                    break;
                case GAME_MAP_SELECTION:
                    // From MAP_SELECTION, can go to IN_GAME (after selection) or back to GAME_MENU (e.g. cancel/error)
                    if (targetMenu == MenuState.IN_GAME || targetMenu == MenuState.GAME_MENU) allowed = true;
                    break;
                case IN_GAME:
                    // From IN_GAME, can go to GAME_MENU (e.g. after exiting a game session)
                    if (targetMenu == MenuState.GAME_MENU) allowed = true;
                    break;
            }
        }

        if (allowed) {
            System.out.println("Entering " + targetMenu + "...");
            setCurrentMenu(targetMenu);
        } else {
            System.out.println("Error: Cannot navigate from " + currentMenu + " to " + targetMenu + " directly or invalid state for navigation.");
        }
    }

    public void exitMenu() {
        switch (currentMenu) {
            case LOGIN_REGISTER:
                System.out.println("Exiting program from Login/Register menu is handled by 'exit_program' command.");
                break;
            case MAIN_MENU:
                System.out.println("Error: Cannot exit Main Menu using 'menu exit'. Use 'user logout' to return to Login/Register or 'exit_program'.");
                break;
            case PROFILE_MENU:
                System.out.println("Exiting Profile Menu...");
                setCurrentMenu(MenuState.MAIN_MENU); // Go back to Main Menu
                break;
            case GAME_MENU:
            case GAME_MAP_SELECTION:
            case IN_GAME:
                System.out.println("Exiting current game-related menu...");
                if (currentUser != null) {
                    if (currentMenu == MenuState.IN_GAME || currentMenu == MenuState.GAME_MAP_SELECTION) {
                        // If exiting from an active game or map selection, go to the general Game Menu
                        setCurrentMenu(MenuState.GAME_MENU);
                    } else if (currentMenu == MenuState.GAME_MENU) {
                        // If already in Game Menu, exiting it means going back to Main Menu
                        setCurrentMenu(MenuState.MAIN_MENU);
                    }
                } else {
                    // Should not happen if game menus are accessed by logged-in users
                    System.out.println("Error: No user logged in. Cannot determine where to exit to. Returning to LOGIN_REGISTER.");
                    setCurrentMenu(MenuState.LOGIN_REGISTER);
                }
                break;
            default:
                System.out.println("Error: No specific exit behavior for " + currentMenu);
        }
    }
}
