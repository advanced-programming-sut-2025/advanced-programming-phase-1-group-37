// File: com/Menus/ForgotPasswordScreen.java
package com.Menus;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Scaling;
import java.util.Optional;

public class ForgotPasswordScreen implements Screen {

    private final StardewGdxGame game;
    private final Stage stage;

    public ForgotPasswordScreen(final StardewGdxGame game) {
        this.game = game;
        this.stage = new Stage(new ScreenViewport());
        Skin skin = game.skin;

        Table table = new Table();
        table.setFillParent(true);
        table.center();
        stage.addActor(table);

        final Label titleLabel = new Label("Password Reset", skin, "default");
        final Label messageLabel = new Label("Please enter your username.", skin);
        final TextField usernameField = new TextField("", skin);
        final TextButton submitButton = new TextButton("Submit", skin);
        final TextButton backButton = new TextButton("Back to Login", skin);

        table.add(titleLabel).colspan(2).padBottom(20);
        table.row();
        table.add(messageLabel).colspan(2).padBottom(20);
        table.row();
        table.add(new Label("Username:", skin)).left().padRight(10);
        table.add(usernameField).width(250).padBottom(20);
        table.row();
        table.add(submitButton).padRight(10);
        table.add(backButton);

        // --- Event Listeners ---
        submitButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                String username = usernameField.getText();
                Optional<SecurityQuestion> sqOpt = game.userService.getSecurityQuestionForUser(username);

                if (sqOpt.isPresent()) {
                    // *** THIS IS THE UPDATE ***
                    // If a question is found, go to the AnswerSecurityQuestionScreen
                    game.setScreen(new AnswerSecurityQuestionScreen(game, username, sqOpt.get()));
                } else {
                    messageLabel.setText("Error: No security question found for this user.");
                }
            }
        });

        backButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.setScreen(new LoginScreen(game));
            }
        });
    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        float screenWidth = Gdx.graphics.getWidth();
        float screenHeight = Gdx.graphics.getHeight();
        float imageWidth = game.backgroundTexture.getWidth();
        float imageHeight = game.backgroundTexture.getHeight();

        Vector2 size = Scaling.fill.apply(imageWidth, imageHeight, screenWidth, screenHeight);
        float x = (screenWidth - size.x) / 2;
        float y = (screenHeight - size.y) / 2;

        game.batch.begin();
        game.batch.draw(game.backgroundTexture, x, y, size.x, size.y);
        game.batch.end();

        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void dispose() {
        stage.dispose();
    }

    @Override
    public void pause() {}
    @Override
    public void resume() {}
    @Override
    public void hide() {}
}
