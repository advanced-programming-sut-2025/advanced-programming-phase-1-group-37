// File: com/Menus/NewGameSetupScreen.java
package com.Menus;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Scaling;
import java.util.ArrayList;

public class NewGameSetupScreen implements Screen {

    private final StardewGdxGame game;
    private final Stage stage;
    private final Skin skin;
    private final ArrayList<String> invitedPlayers;
    private final Label invitedPlayersLabel;
    private final Label messageLabel;

    public NewGameSetupScreen(final StardewGdxGame game) {
        this.game = game;
        this.stage = new Stage(new ScreenViewport());
        this.skin = game.skin;
        this.invitedPlayers = new ArrayList<>();

        Table table = new Table();
        table.setFillParent(true);
        table.center();
        stage.addActor(table);

        // --- UI Elements ---
        Label titleLabel = new Label("New Game Setup", skin, "default");
        final TextField usernameField = new TextField("", skin);
        TextButton addPlayerButton = new TextButton("Add Player", skin);
        invitedPlayersLabel = new Label("Invited: ", skin);
        messageLabel = new Label("", skin);
        TextButton startGameButton = new TextButton("Start Game", skin);
        TextButton backButton = new TextButton("Back", skin);

        // --- Layout ---
        table.add(titleLabel).colspan(2).padBottom(20);
        table.row();
        table.add(new Label("Invite Player (username):", skin)).padRight(10);
        table.add(usernameField).width(200);
        table.row();
        table.add(addPlayerButton).colspan(2).padTop(10).padBottom(20);
        table.row();
        table.add(invitedPlayersLabel).colspan(2).padBottom(20);
        table.row();
        table.add(messageLabel).colspan(2).padBottom(20);
        table.row();

        Table bottomButtons = new Table();
        bottomButtons.add(startGameButton).padRight(10);
        bottomButtons.add(backButton);
        table.add(bottomButtons).colspan(2);

        // --- Event Listeners ---
        addPlayerButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                String username = usernameField.getText();
                if (!username.isEmpty() && !invitedPlayers.contains(username)) {
                    invitedPlayers.add(username);
                    updateInvitedPlayersLabel();
                    usernameField.setText("");
                    messageLabel.setText("");
                } else {
                    messageLabel.setText("Username is empty or already added.");
                }
            }
        });

        startGameButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                User creator = game.currentUserContext.getCurrentUser();
                Game newGame = game.gameService.createNewGame(creator, invitedPlayers);

                if (newGame != null) {
                    game.currentUserContext.setCurrentGame(newGame);
                    // Transition to the map selection screen
                    game.setScreen(new MapSelectionScreen(game, newGame));
                } else {
                    // GameService already prints errors, but we can show one here too.
                    messageLabel.setText("Failed to create game. Check console for details.");
                }
            }
        });

        backButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.setScreen(new GameMenuScreen(game));
            }
        });
    }

    private void updateInvitedPlayersLabel() {
        invitedPlayersLabel.setText("Invited: " + String.join(", ", invitedPlayers));
    }

    @Override
    public void show() { Gdx.input.setInputProcessor(stage); }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        float screenWidth = Gdx.graphics.getWidth();
        float screenHeight = Gdx.graphics.getHeight();
        float imageWidth = game.backgroundTexture.getWidth();
        float imageHeight = game.backgroundTexture.getHeight();
        Vector2 size = Scaling.fill.apply(imageWidth, imageHeight, screenWidth, screenHeight);
        float x = (screenWidth - size.x) / 2;
        float y = (screenHeight - size.y) / 2;

        game.batch.begin();
        game.batch.draw(game.backgroundTexture, x, y, size.x, size.y);
        game.batch.end();

        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) { stage.getViewport().update(width, height, true); }
    @Override
    public void dispose() { stage.dispose(); }
    @Override
    public void pause() {}
    @Override
    public void resume() {}
    @Override
    public void hide() {}
}
