// File: com/Menus/lwjgl3/Lwjgl3Launcher.java
package com.Menus.lwjgl3;

import com.badlogic.gdx.backends.lwjgl3.Lwjgl3Application;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3ApplicationConfiguration;
import com.Menus.StardewGdxGame; // Make sure this is importing StardewGdxGame

/** Launches the desktop (LWJGL3) application. */
public class Lwjgl3Launcher {
    public static void main(String[] args) {
        if (StartupHelper.startNewJvmIfRequired()) return; // This handles macOS support and helps on Windows.
        createApplication();
    }

    private static Lwjgl3Application createApplication() {
        // Make sure this line uses StardewGdxGame
        return new Lwjgl3Application(new StardewGdxGame(), getDefaultConfiguration());
    }

    private static Lwjgl3ApplicationConfiguration getDefaultConfiguration() {
        Lwjgl3ApplicationConfiguration configuration = new Lwjgl3ApplicationConfiguration();
        configuration.setTitle("Menus");

        configuration.useVsync(true);
        configuration.setForegroundFPS(Lwjgl3ApplicationConfiguration.getDisplayMode().refreshRate + 1);

        // --- THIS IS THE CHANGE ---
        // We remove the setWindowedMode line and add setFullscreenMode instead.
        // configuration.setWindowedMode(640, 480); // <-- DELETE OR COMMENT OUT THIS LINE
        configuration.setFullscreenMode(Lwjgl3ApplicationConfiguration.getDisplayMode()); // <-- ADD THIS LINE

        configuration.setWindowIcon("libgdx128.png", "libgdx64.png", "libgdx32.png", "libgdx16.png");
        return configuration;
    }
}
