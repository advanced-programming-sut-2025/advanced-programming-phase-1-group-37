// File: com/Tools/AssetManager.java
package com.Tools;

import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import java.util.HashMap;

public class AssetManager {
    private final HashMap<String, Texture> textures;

    public AssetManager() {
        this.textures = new HashMap<>();
    }

    public void loadAssets() {
        // --- NEW: Load Player Animation Frames ---
        loadTexture("Player_Idle", "player_animation/player_1.png");
        loadTexture("Player_Walk_1", "player_animation/player_2.png");
        loadTexture("Player_Walk_2", "player_animation/player_3.png");

        loadTexture("Chest", "Chest.png");

        // *** NEW: Load Tree and Wood textures ***
        loadTexture("Tree_1", "Trees/tree_1.png");
        loadTexture("Tree_2", "Trees/tree_2.png");
        loadTexture("Tree_3", "Trees/tree_3.png");
        loadTexture("Wood", "Trees/Wood.png");

        // --- NEW: Load Axe Animation Frames ---
        loadTexture("Axe_1", "Axe_animation/Axe_1.png");
        loadTexture("Axe_2", "Axe_animation/Axe_2.png");
        loadTexture("Axe_3", "Axe_animation/Axe_3.png");
        loadTexture("Axe_4", "Axe_animation/Axe_4.png");

        // Load player and map
        loadTexture("Player", "player.jpg");
        loadTexture("Gravel_Path_Tile", "Gravel_Path_Tile.png");

        // Axes
        loadTexture("Axe", "Axe/Axe.png");
        loadTexture("Copper_Axe", "Axe/Copper_Axe.png");
        loadTexture("Gold_Axe", "Axe/Gold_Axe.png");
        loadTexture("Iridium_Axe", "Axe/Iridium_Axe.png");
        loadTexture("Steel_Axe", "Axe/Steel_Axe.png");

        // Pickaxes
        loadTexture("Pickaxe", "Pickaxe/Pickaxe.png");
        loadTexture("Copper_Pickaxe", "Pickaxe/Copper_Pickaxe.png");
        loadTexture("Gold_Pickaxe", "Pickaxe/Gold_Pickaxe.png");
        loadTexture("Iridium_Pickaxe", "Pickaxe/Iridium_Pickaxe.png");
        loadTexture("Steel_Pickaxe", "Pickaxe/Steel_Pickaxe.png");

        // Scythes
        loadTexture("Scythe", "Scythe/Scythe.png");
        loadTexture("Golden_Scythe", "Scythe/Golden_Scythe.png");
        loadTexture("Iridium_Scythe", "Scythe/Iridium_Scythe.png");

        // Watering Cans
        loadTexture("Watering_Can", "Watering_Can/Watering_Can.png");
        loadTexture("Copper_Watering_Can", "Watering_Can/Copper_Watering_Can.png");
        loadTexture("Gold_Watering_Can", "Watering_Can/Gold_Watering_Can.png");
        loadTexture("Iridium_Watering_Can", "Watering_Can/Iridium_Watering_Can.png");
        loadTexture("Steel_Watering_Can", "Watering_Can/Steel_Watering_Can.png");

        // Other Tools
        loadTexture("Dragontooth_Shiv", "shovel/Dragontooth_Shiv.png");
        loadTexture("Milk_Pail", "Milk_Pail.png");
        loadTexture("Shears", "Shears.png");

        // *** NEW: Add the Trash Cans ***
        loadTexture("Trash_Can_Copper", "TrashCan/Trash_Can_Copper.png");
        loadTexture("Trash_Can_Gold", "TrashCan/Trash_Can_Gold.png");
        loadTexture("Trash_Can_Iridium", "TrashCan/Trash_Can_Iridium.png");

        // --- NEW: LOAD PROCESSING ASSETS ---
        // Machines
        loadTexture("Cheese_Press", "processing/cheese_press/Cheese_Press.png");
        loadTexture("Keg", "processing/keg/Keg.png");
        loadTexture("Dehydrator", "processing/dehydrator/Dehydrator.png");
        loadTexture("Mayonnaise_Machine", "processing/mayonnaise_machine/Mayonnaise_Machine.png");
        loadTexture("Oil_Maker", "processing/oil_maker/Oil_Maker.png");
        loadTexture("Preserves_Jar", "processing/preserves_jar/Preserves_Jar.png");
        loadTexture("Fish_Smoker", "processing/fish_smoker/Fish_Smoker.png");
        loadTexture("Furnace", "processing/furnace/Furnace.png");
        loadTexture("Charcoal_Kiln", "processing/charcoal_klin/Charcoal_Kiln.png");

        // Ingredients
        loadTexture("Milk", "processing/cheese_press/Milk.png");
        loadTexture("Goat_Milk", "processing/cheese_press/Goat_Milk.png");
        loadTexture("Corn", "processing/keg/Corn.png");
        loadTexture("Apple", "processing/keg/Apple.png");
        loadTexture("Common_Mushroom", "processing/dehydrator/Common_Mushroom.png");
        loadTexture("Egg", "processing/mayonnaise_machine/Egg.png");
        loadTexture("Sunflower", "processing/oil_maker/Sunflower.png");
        loadTexture("Fish", "processing/fish_smoker/Fish.png");
        loadTexture("Iron_Ore", "processing/furnace/Iron_Ore.png");

        // Products
        loadTexture("Cheese", "processing/cheese_press/Cheese.png");
        loadTexture("Goat_Cheese", "processing/cheese_press/Goat_Cheese.png");
        loadTexture("Juice", "processing/keg/Juice.png");
        loadTexture("Wine", "processing/keg/Wine.png");
        loadTexture("Dried_Mushroom", "processing/dehydrator/Dried_Mushrooms.png"); // Note filename difference
        loadTexture("Dried_Fruit", "processing/dehydrator/Dried_Fruit.png");
        loadTexture("Mayonnaise", "processing/mayonnaise_machine/Mayonnaise.png");
        loadTexture("Oil", "processing/oil_maker/Oil.png");
        loadTexture("Pickles", "processing/preserves_jar/Pickles.png");
        loadTexture("Jelly", "processing/preserves_jar/Jelly.png");
        loadTexture("Smoked_Fish", "processing/fish_smoker/Smoked_Fish.png");
        loadTexture("Iron_Bar", "processing/furnace/Iron_Bar.png");

        // --- NEW: Create textures for the progress bar ---
        // Create a 1x1 red pixel for the background
        Pixmap redPixmap = new Pixmap(1, 1, Pixmap.Format.RGB888);
        redPixmap.setColor(0.5f, 0, 0, 1); // Dark red
        redPixmap.fill();
        textures.put("ProgressBar_BG", new Texture(redPixmap));

        // Create a 1x1 green pixel for the foreground
        Pixmap greenPixmap = new Pixmap(1, 1, Pixmap.Format.RGB888);
        greenPixmap.setColor(0, 0.8f, 0.2f, 1); // Bright green
        greenPixmap.fill();
        textures.put("ProgressBar_FG", new Texture(greenPixmap));

        // --- NEW: Load the texture for the "finished" indicator ---
        loadTexture("Finished_Indicator", "red_circle.png");
    }

    private void loadTexture(String name, String path) {
        try {
            textures.put(name, new Texture(path));
        } catch (Exception e) {
            System.err.println("Failed to load texture: " + name + " at path: " + path);
        }
    }

    public Texture get(String name) {
        return textures.get(name);
    }

    public void dispose() {
        for (Texture texture : textures.values()) {
            texture.dispose();
        }
    }
}
