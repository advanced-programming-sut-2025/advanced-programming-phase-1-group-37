//// File: com/Tools/MachineUI.java
//package com.Tools;
//
//import com.badlogic.gdx.graphics.Texture;
//import com.badlogic.gdx.graphics.g2d.TextureRegion;
//import com.badlogic.gdx.scenes.scene2d.ui.*;
//import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
//import com.badlogic.gdx.utils.Align;
//
//public class MachineUI extends Window {
//
//    private final ProcessingMachine machine;
//    private final AssetManager assetManager;
//
//    private final Image inputImage;
//    private final Image outputImage;
//    private final ProgressBar progressBar;
//
//    public MachineUI(ProcessingMachine machine, AssetManager assetManager, Skin skin) {
//        super(machine.getName().replace("_", " "), skin); // Use the machine's name as the title
//        this.machine = machine;
//        this.assetManager = assetManager;
//
//        this.setResizable(false);
//        this.setMovable(true);
//        this.defaults().pad(10);
//        this.align(Align.center);
//
//        // --- Create UI Elements ---
//        // Input slot shows the required ingredient
//        inputImage = new Image(assetManager.get(machine.getRecipe().getIngredientName()));
//        // Output slot is initially empty
//        outputImage = new Image();
//
//        Label arrowLabel = new Label("-->", skin);
//        progressBar = new ProgressBar(0, machine.getRecipe().getProcessingTime(), 0.1f, false, skin);
//
//        // --- Layout ---
//        this.add(new Label("Input", skin));
//        this.add(); // Empty cell for spacing
//        this.add(new Label("Output", skin));
//        this.row();
//        this.add(inputImage).size(64, 64);
//        this.add(arrowLabel);
//        this.add(outputImage).size(64, 64);
//        this.row();
//        this.add(progressBar).colspan(3).fillX();
//
//        this.pack(); // Size the window to fit its contents
//        this.setVisible(false); // Initially hidden
//    }
//
//    // This method is called every frame to update the UI's appearance
//    public void update() {
//        if (machine.getState() == ProcessingMachine.MachineState.PROCESSING) {
//            // Show the input item and update the progress bar
//            inputImage.setDrawable(new TextureRegionDrawable(new TextureRegion(assetManager.get(machine.getInputItem().getName()))));
//            outputImage.setDrawable(null); // Clear the output slot
//            progressBar.setValue(machine.getRecipe().getProcessingTime() - machine.getProcessingTimer());
//        } else if (machine.getState() == ProcessingMachine.MachineState.FINISHED) {
//            // Show the finished product and fill the progress bar
//            inputImage.setDrawable(null); // Clear the input slot
//            outputImage.setDrawable(new TextureRegionDrawable(new TextureRegion(assetManager.get(machine.getOutputItem().getName()))));
//            progressBar.setValue(machine.getRecipe().getProcessingTime());
//        } else { // IDLE state
//            // Show the required ingredient and empty the progress bar
//            inputImage.setDrawable(new TextureRegionDrawable(new TextureRegion(assetManager.get(machine.getRecipe().getIngredientName()))));
//            outputImage.setDrawable(null);
//            progressBar.setValue(0);
//        }
//    }
//}
