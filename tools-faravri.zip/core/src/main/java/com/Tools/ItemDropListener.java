//// File: com/Tools/ItemDropListener.java
//package com.Tools;
//
//import com.badlogic.gdx.scenes.scene2d.InputEvent;
//import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
//
//// This listener is added to the MachineProcessUI window to handle item placement.
//public class ItemDropListener extends ClickListener {
//
//    private final MachineProcessUI ui;
//    private final ProcessingMachine machine;
//    private final GameScreen gameScreen;
//
//    public ItemDropListener(MachineProcessUI ui, ProcessingMachine machine, GameScreen gameScreen) {
//        this.ui = ui;
//        this.machine = machine;
//        this.gameScreen = gameScreen;
//    }
//
//    @Override
//    public void clicked(InputEvent event, float x, float y) {
//        // Check if the player is currently "holding" an item from their inventory
//        Item itemToPlace = gameScreen.getItemFromCursor();
//        if (itemToPlace != null) {
//            // Try to place the item in the machine
//            if (machine.setIngredient(itemToPlace)) {
//                gameScreen.clearItemFromCursor(); // Success, clear the cursor
//                ui.update(); // Update the UI to show the new item
//            }
//        }
//    }
//}
