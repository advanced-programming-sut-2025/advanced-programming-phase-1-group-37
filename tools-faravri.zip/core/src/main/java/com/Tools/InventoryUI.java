// File: com/Tools/InventoryUI.java
package com.Tools;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Touchable;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Align;

public class InventoryUI extends Window {

    private final Inventory sourceInventory;
    private final AssetManager assetManager;
    private final Player player;
    private final GameScreen gameScreen;

    // For chest-inventory linking
    private InventoryUI otherUI = null;
    private Inventory targetInventory = null;

    // *** NEW: A flag for panel-inventory linking ***
    private boolean isLinkedToPanel = false;

    public InventoryUI(String title, Inventory sourceInventory, AssetManager assetManager, Skin skin, Player player, GameScreen gameScreen) {
        super(title, skin);
        this.sourceInventory = sourceInventory;
        this.assetManager = assetManager;
        this.player = player;
        this.gameScreen = gameScreen;

        this.setResizable(false);
        this.setMovable(true);
        this.defaults().pad(5);
        this.align(Align.center);

        populateInventory();
        this.setVisible(false);
        this.pack();

        // Add a listener to the whole window to handle "dropping" an item
        this.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                if (gameScreen.getItemFromCursor() != null) {
                    if (!sourceInventory.isFull()) {
                        sourceInventory.addItem(gameScreen.getItemFromCursor());
                        gameScreen.clearItemFromCursor();
                        refresh();
                        if (otherUI != null) {
                            otherUI.refresh();
                        }
                    }
                }
            }
        });
    }

    // This method links two inventory UIs together for transferring
    public void link(InventoryUI otherUI, Inventory targetInventory) {
        this.otherUI = otherUI;
        this.targetInventory = targetInventory;
    }

    // *** NEW: A simpler link method for the machine panel ***
    public void linkToProcessPanel(boolean isLinked) {
        this.isLinkedToPanel = isLinked;
    }

    private void populateInventory() {
        this.clearChildren();
        this.add(this.getTitleLabel()).colspan(6).row();

        for (int i = 0; i < sourceInventory.getCapacity(); i++) {
            final int index = i;

            // *** NEW: Use a Stack to layer the image and the count label ***
            Stack itemSlot = new Stack();

            if (i < sourceInventory.getStacks().size()) {
                final ItemStack itemStack = sourceInventory.getStacks().get(i);
                ImageButton itemButton = new ImageButton(new TextureRegionDrawable(new TextureRegion(assetManager.get(itemStack.getItem().getName()))));

                itemSlot.add(itemButton);

                // Add the quantity label if the stack is greater than 1
                if (itemStack.getQuantity() > 1) {
                    Label quantityLabel = new Label(String.valueOf(itemStack.getQuantity()), gameScreen.game.skin);
                    quantityLabel.setAlignment(Align.bottomRight);
                    quantityLabel.setColor(Color.WHITE);
                    // *** THIS IS THE FIX: Make the label ignore mouse clicks ***
                    quantityLabel.setTouchable(Touchable.disabled);
                    itemSlot.add(quantityLabel);
                }

                itemButton.addListener(new ChangeListener() {
                    @Override
                    public void changed(ChangeEvent event, Actor actor) {
                        // The logic for equipping/placing remains the same, but now we use the stack's item
                        Item item = itemStack.getItem();
                        System.out.println(item.getName());
                        if (targetInventory != null) {
                            transferItem(index);
                        }
                        // Priority 2: If linked to a process panel, pick up the item.
                        else if (isLinkedToPanel) {
                            gameScreen.setItemOnCursor(sourceInventory, index);
                        }
                        // Priority 3: If it's a placable machine, start placement.
                        else if (item instanceof MachineItem) {
                            gameScreen.startPlacement((MachineItem) item, sourceInventory, index);
                        }
                        // Default: Equip the item.
                        else {
                            equipItem(index);
                        }
                    }
                });
            }

            this.add(itemSlot).width(40).height(40).pad(5);

            if ((i + 1) % 6 == 0) {
                this.row();
            }
        }
    }

    // *** THIS IS THE NEW, CORRECTED TRANSFER LOGIC ***
    private void transferItem(int index) {
        if (targetInventory == null || otherUI == null) {
            return;
        }

        // 1. Get the type of item we are trying to transfer
        Item itemToTransfer = sourceInventory.getStacks().get(index).getItem();

        // 2. Try to add ONE of that item to the target inventory.
        if (targetInventory.addItem(itemToTransfer)) {
            // 3. If adding was successful, remove ONE from the source stack.
            sourceInventory.takeOneFromStack(index);

            // 4. Refresh both UIs to show the changes.
            this.refresh();
            otherUI.refresh();
        }
    }

    private void equipItem(int index) {
        player.setActiveItemIndex(index);
        gameScreen.closeAllUI();
    }

    public void refresh() {
        populateInventory();
        this.pack();
    }
}
