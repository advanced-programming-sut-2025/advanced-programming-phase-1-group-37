// File: com/Tools/Player.java
package com.Tools;

import com.badlogic.gdx.math.Rectangle;

public class Player {
    // *** NEW: An enum to represent the player's current action ***
    public enum PlayerState {
        IDLE,
        WALKING,
        ATTACKING
    }

    // Position and Movement
    private float x, y;
    private float speed = 150f; // Increased speed slightly

    // Stats
    private int energy;
    private int maxEnergy = 100;

    // Equipment
    private Inventory inventory;
    private int activeItemIndex = 0;

    // *** NEW: State management variables ***
    private PlayerState state;
    private float stateTime; // How long we've been in the current state (for animations)

    private Rectangle hitbox; // *** NEW: Player's hitbox for picking up items ***

    public Player(float startX, float startY) {
        this.x = startX;
        this.y = startY;
        this.energy = maxEnergy;
        this.inventory = new Inventory(36);

        // *** NEW: Set initial state ***
        this.state = PlayerState.IDLE;
        this.stateTime = 0f;
        // *** NEW: Initialize the hitbox. We can adjust the size (48x32) as needed. ***
        this.hitbox = new Rectangle(x, y, 48, 32);
    }

    // This method will be called every frame
    public void update(float deltaTime) {
        // Add the time passed since the last frame to our state timer
        stateTime += deltaTime;
        // *** NEW: Update the hitbox position whenever the player moves ***
        hitbox.setPosition(x, y);
    }

    public void move(float dx, float dy) {
        x += dx * speed;
        y += dy * speed;
    }

    public void useEquippedTool() {
        // *** THIS IS THE FIX: Use getStacks() to check the inventory ***
        if (inventory.getStacks().isEmpty()) {
            System.out.println("No items to use.");
            return;
        }

        // Get the ItemStack first
        ItemStack activeStack = inventory.getStacks().get(activeItemIndex);
        // Then get the Item from the stack
        Item activeItem = activeStack.getItem();

        if (activeItem instanceof Tool) {
            Tool activeTool = (Tool) activeItem;
            if (energy >= activeTool.getEnergyCost()) {
                energy -= activeTool.getEnergyCost();
                System.out.println("Used " + activeTool.getName() + ". Energy is now " + energy);

                // If the tool is the Axe, change state to ATTACKING
                if (activeItem.getName().equals("Axe")) {
                    setState(PlayerState.ATTACKING);
                }
            } else {
                System.out.println("Not enough energy to use " + activeTool.getName());
            }
        } else {
            System.out.println(activeItem.getName() + " is not a tool.");
        }
    }

    // *** NEW: A method to safely change the player's state ***
    public void setState(PlayerState newState) {
        if (this.state != newState) {
            this.state = newState;
            this.stateTime = 0f; // Reset the timer when the state changes
        }
    }

    // --- Getters and Setters ---
    public PlayerState getState() { return state; }
    public float getStateTime() { return stateTime; }
    // ... (rest of your getters and setters) ...
    public void setActiveItemIndex(int index) {
        // *** THIS IS THE FIX: Use getStacks() to check the inventory size ***
        if (index >= 0 && index < inventory.getStacks().size()) {
            this.activeItemIndex = index;
            // Get the item from the stack to print its name
            System.out.println("Equipped: " + inventory.getStacks().get(index).getItem().getName());
        }
    }
    public int getActiveItemIndex() { return activeItemIndex; }
    public float getX() { return x; }
    public float getY() { return y; }
    public int getEnergy() { return energy; }
    public int getMaxEnergy() { return maxEnergy; }
    public Inventory getInventory() { return inventory; }
    public Rectangle getHitbox() { return hitbox; } // *** NEW: Getter for hitbox ***
}
