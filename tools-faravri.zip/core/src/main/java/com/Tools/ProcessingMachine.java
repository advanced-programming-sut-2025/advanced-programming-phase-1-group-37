// File: com/Tools/ProcessingMachine.java
package com.Tools;

import com.badlogic.gdx.math.Rectangle;
import java.util.List;

public class ProcessingMachine {
    public enum MachineState { IDLE, PROCESSING, FINISHED }

    private final String name;
    private final float x, y;
    private final Rectangle hitbox;
    private final List<Recipe> recipes;

    // The machine has its own inventory for the input item
    private final Inventory inputInventory;

    private MachineState state;
    private float processingTimer;
    private float totalProcessingTime;
    private Item outputItem = null;
    private Recipe currentRecipe = null;

    public ProcessingMachine(String name, float x, float y, List<Recipe> recipes) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.recipes = recipes;
        this.hitbox = new Rectangle(x, y, 64, 64);
        this.state = MachineState.IDLE;
        this.processingTimer = 0;
        // Initialize the inventory with a capacity of 1
        this.inputInventory = new Inventory(1);
    }

    public void update(float delta) {
        if (state == MachineState.PROCESSING) {
            processingTimer -= delta;
            if (processingTimer <= 0) {
                outputItem = new Item(currentRecipe.getProductName(), "A processed good.", 99); // Make the product stackable
                state = MachineState.FINISHED;
                currentRecipe = null;
                // *** FIX: Use getStacks() to check the inventory ***
                if (!inputInventory.getStacks().isEmpty()) {
                    // This logic assumes we consume one item from the stack.
                    // If a stack has more than one, it will be handled here.
                    ItemStack stack = inputInventory.getStacks().get(0);
                    stack.setQuantity(stack.getQuantity() - 1);
                    // If the stack is now empty, remove it.
                    if (stack.getQuantity() <= 0) {
                        inputInventory.removeItem(0);
                    }
                }
            }
        }
    }

    private Recipe findRecipeFor(String ingredientName) {
        for (Recipe recipe : recipes) {
            if (recipe.getIngredientName().equals(ingredientName)) {
                return recipe;
            }
        }
        return null;
    }

    public boolean startProcessing() {
        // *** THIS IS THE FIX: Use getStacks() to check the inventory ***
        if (state == MachineState.IDLE && !inputInventory.getStacks().isEmpty()) {
            // Get the ItemStack from the inventory
            ItemStack ingredientStack = inputInventory.getStacks().get(0);
            // Get the Item from the ItemStack
            Item ingredient = ingredientStack.getItem();

            this.currentRecipe = findRecipeFor(ingredient.getName());
            if (this.currentRecipe != null) {
                this.state = MachineState.PROCESSING;
                this.totalProcessingTime = this.currentRecipe.getProcessingTime();
                this.processingTimer = this.totalProcessingTime;
                return true;
            } else {
                return false;
            }
        }
        return false;
    }

    public Item collectProduct() {
        if (state == MachineState.FINISHED) {
            Item productToReturn = this.outputItem;
            this.outputItem = null;
            this.state = MachineState.IDLE;
            return productToReturn;
        }
        return null;
    }

    public ItemStack cancelProcessing() {
        // *** THIS IS THE FIX: Use getStacks() and return the ItemStack ***
        if (state == MachineState.PROCESSING && !inputInventory.getStacks().isEmpty()) {
            // Remove and get the entire ItemStack
            ItemStack ingredientToReturn = inputInventory.removeItem(0);
            this.state = MachineState.IDLE;
            this.processingTimer = 0;
            return ingredientToReturn;
        }
        return null;
    }

    public void cheatFinish() {
        if (state == MachineState.PROCESSING) {
            this.processingTimer = 0;
        }
    }

    // --- Getters ---
    public String getTextureName() { return name; }
    public String getName() { return name; }
    public float getX() { return x; }
    public float getY() { return y; }
    public Rectangle getHitbox() { return hitbox; }
    public List<Recipe> getRecipes() { return recipes; }
    public MachineState getState() { return state; }
    public Item getOutputItem() { return outputItem; }
    public float getProcessingTimer() { return processingTimer; }
    public float getTotalProcessingTime() { return totalProcessingTime; }
    public Inventory getInputInventory() { return inputInventory; }
}
