// File: com/Tools/Recipe.java
package com.Tools;

// This class defines a simple recipe for a processing machine.
public class Recipe {
    private final String ingredientName;
    private final String productName;
    private final float processingTime; // Time in seconds

    public Recipe(String ingredientName, String productName, float processingTime) {
        this.ingredientName = ingredientName;
        this.productName = productName;
        this.processingTime = processingTime;
    }

    public String getIngredientName() { return ingredientName; }
    public String getProductName() { return productName; }
    public float getProcessingTime() { return processingTime; }
}
