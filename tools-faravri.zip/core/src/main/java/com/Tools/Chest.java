// File: com/Tools/Chest.java
package com.Tools;

import com.badlogic.gdx.math.Rectangle;

public class Chest {
    private final float x, y;
    private final Inventory inventory;
    private final Rectangle hitbox;

    public Chest(float x, float y) {
        this.x = x;
        this.y = y;
        // As you requested, the chest has an inventory with 50 slots.
        this.inventory = new Inventory(50);
        // The hitbox for clicking. We can adjust the size (e.g., 48x48) as needed.
        this.hitbox = new Rectangle(x, y, 80, 80);
    }

    public float getX() { return x; }
    public float getY() { return y; }
    public Inventory getInventory() { return inventory; }
    public Rectangle getHitbox() { return hitbox; }
}
