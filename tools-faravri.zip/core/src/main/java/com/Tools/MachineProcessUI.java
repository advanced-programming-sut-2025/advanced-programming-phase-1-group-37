//// File: com/Tools/MachineProcessUI.java
//package com.Tools;
//
//import com.badlogic.gdx.graphics.Texture;
//import com.badlogic.gdx.graphics.g2d.TextureRegion;
//import com.badlogic.gdx.scenes.scene2d.Actor;
//import com.badlogic.gdx.scenes.scene2d.InputEvent;
//import com.badlogic.gdx.scenes.scene2d.ui.*;
//import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
//import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
//import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
//import com.badlogic.gdx.utils.Align;
//
//public class MachineProcessUI extends Window {
//
//    private final ProcessingMachine machine;
//    private final Image inputSlotImage;
//    private final TextButton startButton;
//    private final GameScreen gameScreen;
//
//    public MachineProcessUI(final ProcessingMachine machine, final AssetManager assetManager, Skin skin, final GameScreen gameScreen) {
//        super(machine.getName().replace("_", " "), skin);
//        this.machine = machine;
//        this.gameScreen = gameScreen;
//
//        this.setResizable(false);
//        this.setMovable(true);
//        this.defaults().pad(10);
//        this.align(Align.center);
//
//        inputSlotImage = new Image();
//        startButton = new TextButton("Start", skin);
//        TextButton closeButton = new TextButton("Close", skin);
//
//        this.add(new Label("Input:", skin));
//        this.add(inputSlotImage).size(64, 64).pad(10);
//        this.row();
//        this.add(startButton).pad(5);
//        this.add(closeButton).pad(5);
//
//        // --- NEW: Click listener for the input slot ---
//        inputSlotImage.addListener(new ClickListener() {
//            @Override
//            public void clicked(InputEvent event, float x, float y) {
//                // If the machine already has an item, take it back to the cursor.
//                if (machine.getInputItem() != null) {
//                    gameScreen.setItemOnCursor(machine.takeIngredient());
//                }
//                // If the player is holding an item on the cursor, try to place it.
//                else if (gameScreen.getItemFromCursor() != null) {
//                    Item itemToPlace = gameScreen.getItemFromCursor();
//                    if (machine.setIngredient(itemToPlace)) {
//                        gameScreen.clearItemFromCursor(); // Success, clear the cursor
//                    }
//                }
//                update(); // Refresh the UI
//            }
//        });
//
//        startButton.addListener(new ChangeListener() {
//            @Override
//            public void changed(ChangeEvent event, Actor actor) {
//                machine.startProcessing();
//                gameScreen.closeAllUI();
//            }
//        });
//
//        closeButton.addListener(new ChangeListener() {
//            @Override
//            public void changed(ChangeEvent event, Actor actor) {
//                gameScreen.closeAllUI();
//            }
//        });
//
//        update();
//        this.pack();
//        this.setVisible(false);
//    }
//
//    public void update() {
//        if (machine.getInputItem() != null) {
//            Texture itemTexture = gameScreen.game.assetManager.get(machine.getInputItem().getName());
//            inputSlotImage.setDrawable(new TextureRegionDrawable(new TextureRegion(itemTexture)));
//            startButton.setDisabled(false);
//        } else {
//            // The slot is now empty by default
//            inputSlotImage.setDrawable(null);
//            startButton.setDisabled(true);
//        }
//    }
//}
