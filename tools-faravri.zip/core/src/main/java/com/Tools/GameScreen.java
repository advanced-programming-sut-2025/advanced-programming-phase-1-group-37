// File: com/Tools/GameScreen.java
package com.Tools;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector3; // Import Vector3
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

import java.util.Arrays;
import java.util.Iterator;
import java.util.Random; // Import Random

public class GameScreen implements Screen {

    public final ToolsGame game;
    private final GameMap gameMap;
    private final Player player;
    private final Random random = new Random(); // For dropping items

    // Graphics and Camera
    private final OrthographicCamera camera;
    private final Texture mapTileTexture;

    // UI (Heads-Up Display)
    private final Stage hudStage;
    private final ProgressBar energyBar;
    private final Label equippedItemLabel;
    public final InventoryUI playerInventoryUI;
    public InventoryUI chestInventoryUI; // *** NEW: The UI for the currently open chest ***
    private boolean isChestOpen = false; // *** NEW: Flag for chest state ***
    private boolean isInventoryOpen = false;
    // *** NEW: State variables for machine placement ***
    private boolean isPlacingMachine = false;
    private MachineItem machineToPlace = null;
    private Inventory placementSourceInventory = null;
    private int placementSourceIndex = -1;
    // *** NEW: State variables for machine interaction ***
//    private MachineUI currentMachineUI = null;
//    private MachineProcessUI currentProcessUI = null;
    private Window currentMenuUI = null;
    private ProcessingMachine activeMachine = null;
    // This represents an item being "held" by the cursor to be placed in a machine
    private ItemStack itemOnCursor = null;
    private int itemOnCursorSourceIndex = -1;

    // --- NEW State Management Variables ---
    private Inventory itemOnCursorSourceInventory = null;

    private InventoryUI machineInputUI; // *** NEW: The UI for the machine's input slot ***
    private Window machineActionPanel; // *** NEW: A separate panel for the "Start" button ***

    // Animation objects and the idle texture
    private final Texture playerIdleTexture;
    private final Animation<TextureRegion> playerWalkAnimation;
    private final Animation<TextureRegion> axeSwingAnimation;

    private float animationTimer = 0; // *** NEW: A timer for simple animations ***

    public GameScreen(final ToolsGame game) {
        this.game = game;

        // --- Initialize Game Logic ---
        this.gameMap = new GameMap(3200, 1800);
        this.player = new Player(1600, 900);

        // --- NEW: Create machines with lists of recipes ---
        float machineX = player.getX() - 300;
        float machineY = player.getY() + 200;
        gameMap.addMachine(new ProcessingMachine("Cheese_Press", machineX, machineY,
            Arrays.asList(
                new Recipe("Milk", "Cheese", 5f),
                new Recipe("Goat_Milk", "Goat_Cheese", 5f)
            )
        ));

        // --- NEW: Create machines with lists of recipes ---
//        float machineX = player.getX() - 300;
//        float machineY = player.getY() + 200;
//        gameMap.addMachine(new ProcessingMachine("Cheese_Press", machineX, machineY,
//            Arrays.asList(
//                new Recipe("Milk", "Cheese", 5f),
//                new Recipe("Goat_Milk", "Goat_Cheese", 5f)
//            )
//        ));

        // Give the player a "Milk" item to test the Cheese Press
        player.getInventory().addItem(new Item("Milk", "Fresh milk."));
        player.getInventory().addItem(new Item("Goat_Milk", "Fresh goat milk."));

        // *** NEW: Spawn trees on the map ***
        gameMap.spawnTrees(20);
        // *** NEW: Create a chest and add it to the map ***
        Chest mainChest = new Chest(player.getX(), player.getY() + 100);
        gameMap.addChest(mainChest);
        // *** NEW: Add all machines as ITEMS to the chest's inventory ***
        Inventory chestInventory = mainChest.getInventory();
        chestInventory.addItem(new MachineItem("Cheese_Press", "Makes cheese.", new Recipe("Milk", "Cheese", 5f)));
        chestInventory.addItem(new MachineItem("Keg", "Makes drinks.", new Recipe("Corn", "Juice", 8f)));
        chestInventory.addItem(new MachineItem("Dehydrator", "Dries things.", new Recipe("Common_Mushroom", "Dried_Mushroom", 4f)));
        chestInventory.addItem(new MachineItem("Mayonnaise_Machine", "Makes mayo.", new Recipe("Egg", "Mayonnaise", 3f)));
        chestInventory.addItem(new MachineItem("Oil_Maker", "Makes oil.", new Recipe("Sunflower", "Oil", 6f)));
        chestInventory.addItem(new MachineItem("Preserves_Jar", "Makes preserves.", new Recipe("Corn", "Pickles", 10f)));
        chestInventory.addItem(new MachineItem("Fish_Smoker", "Smokes fish.", new Recipe("Fish", "Smoked_Fish", 2f)));
        chestInventory.addItem(new MachineItem("Furnace", "Smelts ore.", new Recipe("Iron_Ore", "Iron_Bar", 12f)));
        // *** NEW: Add the Charcoal Kiln as an item to the chest ***
        // Wood is the ingredient, Coal is the product, takes 15 seconds.
        chestInventory.addItem(new MachineItem("Charcoal_Kiln", "Turns wood into coal.", new Recipe("Wood", "Coal", 15f)));

        // Restore the full inventory
        // (Your full list of player.getInventory().addItem calls goes here)
        player.getInventory().addItem(new Tool("Axe", "A basic axe.", 5));
        // *** FIX: Restore the full inventory ***
        player.getInventory().addItem(new Tool("Copper_Axe", "A copper axe.", 4));
        player.getInventory().addItem(new Tool("Steel_Axe", "A steel axe.", 3));
        player.getInventory().addItem(new Tool("Gold_Axe", "A gold axe.", 2));
        player.getInventory().addItem(new Tool("Iridium_Axe", "An iridium axe.", 1));
        player.getInventory().addItem(new Tool("Pickaxe", "A basic pickaxe.", 7));
        player.getInventory().addItem(new Tool("Copper_Pickaxe", "A copper pickaxe.", 6));
        player.getInventory().addItem(new Tool("Steel_Pickaxe", "A steel pickaxe.", 5));
        player.getInventory().addItem(new Tool("Gold_Pickaxe", "A gold pickaxe.", 4));
        player.getInventory().addItem(new Tool("Iridium_Pickaxe", "An iridium pickaxe.", 3));
        player.getInventory().addItem(new Tool("Scythe", "A basic scythe.", 2));
        player.getInventory().addItem(new Tool("Golden_Scythe", "A golden scythe.", 1));
        player.getInventory().addItem(new Tool("Iridium_Scythe", "An iridium scythe.", 0));
        player.getInventory().addItem(new Tool("Watering_Can", "A can for watering.", 1));
        player.getInventory().addItem(new Tool("Copper_Watering_Can", "A copper can.", 1));
        player.getInventory().addItem(new Tool("Steel_Watering_Can", "A steel can.", 1));
        player.getInventory().addItem(new Tool("Gold_Watering_Can", "A gold can.", 1));
        player.getInventory().addItem(new Tool("Iridium_Watering_Can", "An iridium can.", 1));
        player.getInventory().addItem(new Tool("Dragontooth_Shiv", "A sharp dagger.", 10));
        player.getInventory().addItem(new Tool("Milk_Pail", "For milking cows.", 0));
        player.getInventory().addItem(new Tool("Shears", "For shearing sheep.", 0));
        player.getInventory().addItem(new Tool("Trash_Can_Copper", "A copper trash can.", 0));
        player.getInventory().addItem(new Tool("Trash_Can_Gold", "A gold trash can.", 0));
        player.getInventory().addItem(new Tool("Trash_Can_Iridium", "An iridium trash can.", 0));

        // --- Initialize Camera & Animations (your existing code) ---
        this.camera = new OrthographicCamera();
        this.camera.setToOrtho(false, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        this.mapTileTexture = game.assetManager.get("Gravel_Path_Tile");
        this.playerIdleTexture = game.assetManager.get("Player_Idle");
        Texture walk1 = game.assetManager.get("Player_Walk_1");
        Texture walk2 = game.assetManager.get("Player_Walk_2");
        this.playerWalkAnimation = new Animation<>(0.25f, new TextureRegion(walk1), new TextureRegion(walk2));
        this.playerWalkAnimation.setPlayMode(Animation.PlayMode.LOOP);
        Texture axe1 = game.assetManager.get("Axe_1");
        Texture axe2 = game.assetManager.get("Axe_2");
        Texture axe3 = game.assetManager.get("Axe_3");
        Texture axe4 = game.assetManager.get("Axe_4");
        this.axeSwingAnimation = new Animation<>(0.13f,
            new TextureRegion(axe1), new TextureRegion(axe2),
            new TextureRegion(axe3), new TextureRegion(axe4));
        this.axeSwingAnimation.setPlayMode(Animation.PlayMode.NORMAL);

        // --- Initialize HUD (your existing code) ---
        this.hudStage = new Stage(new ScreenViewport());
        Skin skin = game.skin;
        Table hudTable = new Table();
        hudTable.setFillParent(true);
        hudTable.top().right();
        energyBar = new ProgressBar(0, player.getMaxEnergy(), 1, false, skin);
        equippedItemLabel = new Label("", skin);
        hudTable.add(new Label("Energy", skin)).pad(10);
        hudTable.add(energyBar).width(200).pad(10);
        hudTable.row();
        hudTable.add(new Label("Equipped:", skin)).pad(10);
        hudTable.add(equippedItemLabel).pad(10);
        hudStage.addActor(hudTable);
        playerInventoryUI = new InventoryUI("Player Inventory", player.getInventory(), game.assetManager, skin, player, this);
        hudStage.addActor(playerInventoryUI);
        playerInventoryUI.setPosition(
            (hudStage.getWidth() - playerInventoryUI.getWidth()) / 2,
            (hudStage.getHeight() - playerInventoryUI.getHeight()) / 2
        );
//        hudStage.addActor(playerInventoryUI);
    }

    // *** NEW: A separate update method for game logic ***
    private void update(float delta) {
        animationTimer += delta;

//        if (isInventoryOpen || isChestOpen || isPlacingMachine || currentProcessUI != null || currentMenuUI != null) return;
        if (isInventoryOpen || isChestOpen || isPlacingMachine || currentMenuUI != null) return;


        player.update(delta);

        // *** NEW: Update all machines on the map ***
        for (ProcessingMachine machine : gameMap.getMachines()) {
            machine.update(delta);
        }
        // *** NEW: If a machine UI is open, keep it updated ***
//        if (currentMachineUI != null) {
//            currentMachineUI.update();
//        }

        if (player.getState() == Player.PlayerState.ATTACKING && axeSwingAnimation.isAnimationFinished(player.getStateTime())) {
            player.setState(Player.PlayerState.IDLE);
        }

        camera.position.set(player.getX(), player.getY(), 0);
        camera.update();

        // *** UPDATED: Check for item pickup ***
        Iterator<WorldItem> itemIterator = gameMap.getDroppedItems().iterator();
        while (itemIterator.hasNext()) {
            WorldItem worldItem = itemIterator.next();
            if (player.getHitbox().overlaps(worldItem.getHitbox())) {
                // Create a new Item object for the wood. Let's say it can stack up to 99.
                Item woodItem = new Item(worldItem.getName(), "A piece of wood.", 99);
                if (player.getInventory().addItem(woodItem)) {
                    itemIterator.remove();
                    playerInventoryUI.refresh();
                }
            }
        }
    }

    @Override
    public void render(float delta) {
        handleInput(delta);
        update(delta); // Call our new update method
        player.update(delta);

        if (player.getState() == Player.PlayerState.ATTACKING && axeSwingAnimation.isAnimationFinished(player.getStateTime())) {
            player.setState(Player.PlayerState.IDLE);
        }

        if (!isInventoryOpen) {
            camera.position.set(player.getX(), player.getY(), 0);
            camera.update();
        }

        energyBar.setValue(player.getEnergy());
        updateEquippedItemLabel();

        Gdx.gl.glClearColor(0.1f, 0.1f, 0.1f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        game.batch.setProjectionMatrix(camera.combined);

        game.batch.begin();
        // *** NEW: Call the new drawing methods in the correct order ***
        drawMap();
        drawDroppedItems();
        drawTrees();
        drawChests(); // *** NEW: Draw the chests ***
        drawMachines();
        drawPlayer();
        drawMachineProgressBars();
        drawMachineFinishedIndicators();

        if (isPlacingMachine) {
            drawMachinePlacement();
        }

        drawMachineProgressBars(); // *** NEW ***
//        drawItemOnCursor(); // *** NEW ***

        game.batch.end();

        hudStage.act(delta);
        hudStage.draw();
    }

    // --- NEW Drawing Methods ---
    private void drawMap() {
        for (int x = 0; x < gameMap.getWidth(); x += mapTileTexture.getWidth()) {
            for (int y = 0; y < gameMap.getHeight(); y += mapTileTexture.getHeight()) {
                game.batch.draw(mapTileTexture, x, y);
            }
        }
    }

    private void drawTrees() {
        for (Tree tree : gameMap.getTrees()) {
            Texture treeTexture = game.assetManager.get(tree.getTextureName());
            if (treeTexture != null) {
                float width = (tree.getTextureName().equals("Tree_3")) ? 50 : 128;
                float height = (tree.getTextureName().equals("Tree_3")) ? 50 : 128;
//                float width = 96;
//                float height = 96;
                game.batch.draw(treeTexture, tree.getX(), tree.getY(), width, height);            }
        }
    }

    // *** NEW: Method to draw chests on the map ***
    private void drawChests() {
        Texture chestTexture = game.assetManager.get("Chest");
        if (chestTexture != null) {
            for (Chest chest : gameMap.getChests()) {
                game.batch.draw(chestTexture, chest.getX(), chest.getY());
            }
        }
    }

    private void drawDroppedItems() {
        for (WorldItem item : gameMap.getDroppedItems()) {
            Texture itemTexture = game.assetManager.get(item.getName());
            if (itemTexture != null) {
                game.batch.draw(itemTexture, item.getX(), item.getY());
            }
        }
    }

    private void drawPlayer() {
        TextureRegion playerFrame = (player.getState() == Player.PlayerState.WALKING)
            ? playerWalkAnimation.getKeyFrame(player.getStateTime(), true)
            : new TextureRegion(playerIdleTexture);
        game.batch.draw(playerFrame, player.getX(), player.getY(), 64, 64);

        if (player.getState() == Player.PlayerState.ATTACKING) {
            TextureRegion axeFrame = axeSwingAnimation.getKeyFrame(player.getStateTime(), false);
            game.batch.draw(axeFrame, player.getX() + 65, player.getY() + 20, 64, 64);
        } else {
            drawEquippedTool();
        }
    }

    private void drawEquippedTool() {
        // Check if the inventory has any stacks
        if (!player.getInventory().getStacks().isEmpty()) {
            // Get the ItemStack at the active index
            ItemStack equippedStack = player.getInventory().getStacks().get(player.getActiveItemIndex());
            // Get the Item from the ItemStack
            Item equippedItem = equippedStack.getItem();

            Texture toolTexture = game.assetManager.get(equippedItem.getName());
            if (toolTexture != null) {
                game.batch.draw(toolTexture, player.getX() + 65, player.getY() + 20);
            }
        }
    }

    // *** NEW: Method to draw the machine being placed ***
    private void drawMachinePlacement() {
        Texture machineTexture = game.assetManager.get(machineToPlace.getName());
        if (machineTexture != null) {
            // Get the mouse position in world coordinates
            Vector3 mouseInWorld = camera.unproject(new Vector3(Gdx.input.getX(), Gdx.input.getY(), 0));
            // Draw the texture centered on the mouse cursor
            game.batch.draw(machineTexture, mouseInWorld.x - machineTexture.getWidth() / 2, mouseInWorld.y - machineTexture.getHeight() / 2);
        }
    }

    // *** ADD THIS MISSING METHOD TO YOUR GAMESCREEN.JAVA ***
    private void drawMachines() {
        for (ProcessingMachine machine : gameMap.getMachines()) {
            Texture machineTexture = game.assetManager.get(machine.getTextureName());
            if (machineTexture != null) {
                game.batch.draw(machineTexture, machine.getX(), machine.getY());
            }
        }
    }

    // *** NEW: Method to draw progress bars over machines in the world ***
//    private void drawMachineProgressBars() {
//        for (ProcessingMachine machine : gameMap.getMachines()) {
//            if (machine.getState() == ProcessingMachine.MachineState.PROCESSING) {
//                // This is a simple way to draw a progress bar manually
//                float progress = 1 - (machine.getProcessingTimer() / machine.getTotalProcessingTime());
//                Texture greenBar = game.assetManager.get("GreenBar"); // You'll need to create a simple green pixel texture
//                if (greenBar != null) {
//                    game.batch.draw(greenBar, machine.getX(), machine.getY() + 64, 64 * progress, 8);
//                }
//            }
//        }
//    }

    private void drawMachineProgressBars() {
        Texture bgTexture = game.assetManager.get("ProgressBar_BG");
        Texture fgTexture = game.assetManager.get("ProgressBar_FG");

        if (bgTexture == null || fgTexture == null) return; // Don't draw if textures aren't ready

        for (ProcessingMachine machine : gameMap.getMachines()) {
            if (machine.getState() == ProcessingMachine.MachineState.PROCESSING) {
                // Calculate the progress percentage
                float progress = 1 - (machine.getProcessingTimer() / machine.getTotalProcessingTime());

                // Define the size and position of the bar, just above the machine
                float barX = machine.getX();
                float barY = machine.getY() + 68; // 64 pixels for machine height + 4 pixels of padding
                float barWidth = 64;
                float barHeight = 8;

                // Draw the red background bar (full width)
                game.batch.draw(bgTexture, barX - 23, barY, barWidth, barHeight);
                // Draw the green foreground bar, scaled by the progress
                game.batch.draw(fgTexture, barX - 23, barY, barWidth * progress, barHeight);
            }
        }
    }

    private void drawMachineFinishedIndicators() {
        Texture indicatorBg = game.assetManager.get("Finished_Indicator");
        if (indicatorBg == null) return;

        for (ProcessingMachine machine : gameMap.getMachines()) {
            if (machine.getState() == ProcessingMachine.MachineState.FINISHED && machine.getOutputItem() != null) {
                Texture productTexture = game.assetManager.get(machine.getOutputItem().getName());
                if (productTexture != null) {
                    // Calculate a bobbing effect using a sine wave
                    float bobOffset = (float) (Math.sin(animationTimer * 3f) * 4); // Bounces 4 pixels up and down

                    // Position the indicator above the machine
                    float iconX = machine.getX() + 16;
                    float iconY = machine.getY() + 72 + bobOffset;

                    // Draw the red circle first
                    game.batch.draw(indicatorBg, iconX - 21, iconY, 32, 32);
                    // Draw the product icon on top of the circle
                    //game.batch.draw(productTexture, iconX, iconY, 32, 32);
                }
            }
        }
    }

    // *** NEW: Method to draw the item being held by the cursor ***
//    private void drawItemOnCursor() {
//        if (itemOnCursor != null) {
//            Texture itemTexture = game.assetManager.get(itemOnCursor.getName());
//            if (itemTexture != null) {
//                // Draw the item texture centered on the hardware cursor
//                Gdx.input.setCursorCatched(true); // Hide the OS cursor
//                Vector3 mouseInWorld = camera.unproject(new Vector3(Gdx.input.getX(), Gdx.input.getY(), 0));
//                game.batch.draw(itemTexture, mouseInWorld.x - 16, mouseInWorld.y - 16, 32, 32);
//            }
//        } else {
//            Gdx.input.setCursorCatched(false); // Show the OS cursor
//        }
//    }

    private void handleInput(float delta) {
        // --- Placement Mode Input ---
        // If we are currently placing a machine, this is the only input we process.
        if (isPlacingMachine) {
            // Left click to place the machine
            if (Gdx.input.isButtonJustPressed(Input.Buttons.LEFT)) {
                Vector3 mouseInWorld = camera.unproject(new Vector3(Gdx.input.getX(), Gdx.input.getY(), 0));
                placementSourceInventory.removeItem(placementSourceIndex);
                playerInventoryUI.refresh();
                if (chestInventoryUI != null) chestInventoryUI.refresh();

                gameMap.addMachine(new ProcessingMachine(
                    machineToPlace.getName(),
                    mouseInWorld.x - 32,
                    mouseInWorld.y - 32,
                    Arrays.asList(machineToPlace.getRecipe())
                ));
                isPlacingMachine = false;
                machineToPlace = null;
            }
            // Right click to cancel placement
            if (Gdx.input.isButtonJustPressed(Input.Buttons.RIGHT)) {
                isPlacingMachine = false;
                machineToPlace = null;
            }
            return; // Stop processing any other input
        }

        // --- Item on Cursor Input ---
        if (itemOnCursor != null) {
            // A right click while holding an item always cancels and returns it.
            if (Gdx.input.isButtonJustPressed(Input.Buttons.RIGHT)) {
                itemOnCursorSourceInventory.addItem(itemOnCursor);
                playerInventoryUI.refresh();
                if (chestInventoryUI != null) chestInventoryUI.refresh();
                clearItemFromCursor();
            }
            // Left clicks are handled by UI listeners, so we don't process other input.
            return;
        }

        // --- UI Toggles ---
        if (Gdx.input.isKeyJustPressed(Input.Keys.E)) {
//            if (isChestOpen || currentProcessUI != null || currentMenuUI != null)
            if (isChestOpen || currentMenuUI != null || machineInputUI != null) {
                closeAllUI();
            } else {
                isInventoryOpen = !isInventoryOpen;
                playerInventoryUI.setVisible(isInventoryOpen);

                // *** FIX: Unlink the inventory when it's opened alone ***
                playerInventoryUI.link(null, null);
                playerInventoryUI.linkToProcessPanel(false);

                // *** NEW: Unlink the inventory when opening it alone ***
//                playerInventoryUI.link(null);

                // *** NEW: Set to EQUIP mode when opened alone ***
//                playerInventoryUI.setTransferMode(false);
//                playerInventoryUI.link(null, null);
                playerInventoryUI.setPosition(
                    (hudStage.getWidth() - playerInventoryUI.getWidth()) / 2,
                    (hudStage.getHeight() - playerInventoryUI.getHeight()) / 2
                );
            }
        }

        // --- World Interaction Clicks ---
        if (Gdx.input.isButtonJustPressed(Input.Buttons.LEFT)) {
            handleLeftClick();
        }
        if (Gdx.input.isButtonJustPressed(Input.Buttons.RIGHT)) {
            handleRightClick();
        }

        // --- Player Movement ---
        // Stop movement if any UI is open or if the player is attacking.
//        if (isInventoryOpen || isChestOpen || currentProcessUI != null || currentMenuUI != null
//            || player.getState() == Player.PlayerState.ATTACKING) return;
        if (isInventoryOpen || isChestOpen || currentMenuUI != null
            || player.getState() == Player.PlayerState.ATTACKING) return;

        boolean isMoving = false;
        if (Gdx.input.isKeyPressed(Input.Keys.W)) { player.move(0, delta); isMoving = true; }
        if (Gdx.input.isKeyPressed(Input.Keys.S)) { player.move(0, -delta); isMoving = true; }
        if (Gdx.input.isKeyPressed(Input.Keys.A)) { player.move(-delta, 0); isMoving = true; }
        if (Gdx.input.isKeyPressed(Input.Keys.D)) { player.move(delta, 0); isMoving = true; }

        if (isMoving) {
            player.setState(Player.PlayerState.WALKING);
        } else {
            player.setState(Player.PlayerState.IDLE);
        }
    }

    private void handleLeftClick() {
        // If a UI window is open, the click should be handled by the UI, not the game world.
//        if (isInventoryOpen || isChestOpen || currentProcessUI != null || currentMenuUI != null) {
//            return;
//        }
        if (isInventoryOpen || isChestOpen || currentMenuUI != null) {
            return;
        }

        // If holding an item on the cursor, a left click will cancel the action.
        if (itemOnCursor != null) {
            player.getInventory().addItem(itemOnCursor);
            playerInventoryUI.refresh();
            clearItemFromCursor();
            return;
        }

        Vector3 mouseInWorld = camera.unproject(new Vector3(Gdx.input.getX(), Gdx.input.getY(), 0));

        // 1. Check for Machine Process Panel interaction
        for (ProcessingMachine machine : gameMap.getMachines()) {
            if (machine.getHitbox().contains(mouseInWorld.x, mouseInWorld.y)) {
                float distance = (float) Math.sqrt(Math.pow(player.getX() - machine.getX(), 2) + Math.pow(player.getY() - machine.getY(), 2));
                if (distance < 100) {
                    openProcessUI(machine);
                    return; // Stop further processing
                }
            }
        }

        // 2. If no machine was clicked, perform the default tool action (axe swing)
        // *** THIS IS THE FIX: Get the item from the ItemStack ***
        if (!player.getInventory().getStacks().isEmpty()) {
            ItemStack equippedStack = player.getInventory().getStacks().get(player.getActiveItemIndex());
            Item equipped = equippedStack.getItem();

            if (equipped.getName().equals("Axe")) {
                player.useEquippedTool();
                // Check if the swing also hit a tree
                for (Tree tree : gameMap.getTrees()) {
                    if (!tree.isBroken() && tree.getHitbox().contains(mouseInWorld.x, mouseInWorld.y)) {
                        float distance = (float) Math.sqrt(Math.pow(player.getX() - tree.getX(), 2) + Math.pow(player.getY() - tree.getY(), 2));
                        if (distance < 100) {
                            tree.hit();
                            if (tree.isBroken()) {
                                gameMap.addDroppedItem(new WorldItem("Wood", tree.getX() + random.nextInt(60) - 30, tree.getY()));
                                gameMap.addDroppedItem(new WorldItem("Wood", tree.getX() + random.nextInt(60) - 30, tree.getY()));
                            }
                            break;
                        }
                    }
                }
            }
        }
    }

    private void handleRightClick() {
        // If any UI is already open, a right click will close it.
//        if (isInventoryOpen || isChestOpen || currentProcessUI != null || currentMenuUI != null) {
//            closeAllUI();
//            return;
//        }
        if (isInventoryOpen || isChestOpen || currentMenuUI != null) {
            closeAllUI();
            return;
        }

        Vector3 mouseInWorld = camera.unproject(new Vector3(Gdx.input.getX(), Gdx.input.getY(), 0));

        // 1. Check for Machine Menu interaction
        for (ProcessingMachine machine : gameMap.getMachines()) {
            if (machine.getHitbox().contains(mouseInWorld.x, mouseInWorld.y)) {
                float distance = (float) Math.sqrt(Math.pow(player.getX() - machine.getX(), 2) + Math.pow(player.getY() - machine.getY(), 2));
                if (distance < 100) {
                    openMenuUI(machine);
                    return; // Stop further processing
                }
            }
        }

        // 2. Check for Chest interaction
        for (Chest chest : gameMap.getChests()) {
            if (chest.getHitbox().contains(mouseInWorld.x, mouseInWorld.y)) {
                float distance = (float) Math.sqrt(Math.pow(player.getX() - chest.getX(), 2) + Math.pow(player.getY() - chest.getY(), 2));
                if (distance < 100) {
                    toggleChestUI(chest);
                    return;
                }
            }
        }
    }

    public void closeAllUI() {
        // Close player inventory
        isInventoryOpen = false;
        playerInventoryUI.setVisible(false);

        // Close chest UI
        isChestOpen = false;
        if (chestInventoryUI != null) {
            chestInventoryUI.remove();
            chestInventoryUI = null;
        }

        // *** NEW: Close the machine UIs ***
        if (machineInputUI != null) {
            machineInputUI.remove();
            machineInputUI = null;
        }
        if (machineActionPanel != null) {
            machineActionPanel.remove();
            machineActionPanel = null;
        }

        // Close machine process panel
//        if (currentProcessUI != null) {
//            currentProcessUI.remove();
//            currentProcessUI = null;
//        }

        // Close machine menu
        if (currentMenuUI != null) {
            currentMenuUI.remove();
            currentMenuUI = null;
        }

        // If the player was holding an item on the cursor, return it to their inventory
        if (itemOnCursor != null) {
            player.getInventory().addItem(itemOnCursor);
            playerInventoryUI.refresh();
            clearItemFromCursor();
        }

        // *** NEW: Reset the player inventory's mode when closing everything ***
//        playerInventoryUI.setTransferMode(false);

        // *** FIX: Reset the player inventory's link when closing everything ***
        playerInventoryUI.link(null, null);
        if (chestInventoryUI != null) {
            chestInventoryUI.remove();
            chestInventoryUI = null;
        }
        playerInventoryUI.linkToProcessPanel(false);

        activeMachine = null;
    }

    // *** NEW: Methods to manage the chest UI state ***
    private void toggleChestUI(Chest chest) {
        isChestOpen = !isChestOpen;

        if (isChestOpen) {
            // *** CHANGED: Pass 'player' and 'this' to the chest UI constructor too ***
            chestInventoryUI = new InventoryUI("Chest", chest.getInventory(), game.assetManager, game.skin, player, this);

            // *** FIX: Link the two UIs together for transfer mode ***
            playerInventoryUI.link(chestInventoryUI, chest.getInventory());
            chestInventoryUI.link(playerInventoryUI, player.getInventory());

            // *** NEW: Link the two UIs together for transfer mode ***
//            playerInventoryUI.link(chestInventoryUI);
//            chestInventoryUI.link(playerInventoryUI);

            // *** NEW: Set both UIs to TRANSFER mode ***
//            playerInventoryUI.setTransferMode(true);
//            chestInventoryUI.setTransferMode(true);

//            playerInventoryUI.link(chestInventoryUI, chest.getInventory());
//            chestInventoryUI.link(playerInventoryUI, player.getInventory());

            float totalWidth = playerInventoryUI.getWidth() + chestInventoryUI.getWidth() + 20;
            playerInventoryUI.setPosition((hudStage.getWidth() - totalWidth) / 2, (hudStage.getHeight() - playerInventoryUI.getHeight()) / 2);
            chestInventoryUI.setPosition(playerInventoryUI.getX() + playerInventoryUI.getWidth() + 20, playerInventoryUI.getY());

            hudStage.addActor(chestInventoryUI);
        }

        playerInventoryUI.setVisible(isChestOpen);
        if (chestInventoryUI != null) {
            chestInventoryUI.setVisible(isChestOpen);
        }
    }

    private void closeChestUI() {
        isChestOpen = false;
        playerInventoryUI.setVisible(false);
        if (chestInventoryUI != null) {
            chestInventoryUI.remove(); // Remove the chest UI from the stage
            chestInventoryUI = null;
        }
    }

    // ... (rest of your GameScreen code: closeInventory, updateEquippedItemLabel, show, resize, dispose, etc.) ...
    public void closeInventory() {
        isInventoryOpen = false;
        playerInventoryUI.setVisible(false);
    }

    private void updateEquippedItemLabel() {
        // Check if the inventory has any stacks
        if (!player.getInventory().getStacks().isEmpty()) {
            // Get the ItemStack at the active index
            ItemStack equippedStack = player.getInventory().getStacks().get(player.getActiveItemIndex());
            // Get the Item from the ItemStack
            Item equippedItem = equippedStack.getItem();

            equippedItemLabel.setText(equippedItem.getName());
        } else {
            equippedItemLabel.setText("None");
        }
    }

    // *** CHANGED: Updated method signature ***
    public void startPlacement(MachineItem item, Inventory sourceInventory, int sourceIndex) {
        this.machineToPlace = item;
        this.isPlacingMachine = true;
        this.placementSourceInventory = sourceInventory;
        this.placementSourceIndex = sourceIndex;

        closeInventory();
        closeChestUI();
    }

    // --- NEW UI Management Methods ---
    private void openProcessUI(final ProcessingMachine machine) {
        closeAllUI();
        activeMachine = machine;

        // --- Create the two linked inventory UIs, just like the chest ---
        isInventoryOpen = true;

        // Create a new InventoryUI for the machine's single slot
        machineInputUI = new InventoryUI("Input", machine.getInputInventory(), game.assetManager, game.skin, player, this);

        // Link the player's inventory to the machine's inventory
        playerInventoryUI.link(machineInputUI, machine.getInputInventory());
        // Link the machine's inventory to the player's inventory
        machineInputUI.link(playerInventoryUI, player.getInventory());

        // --- Create the separate action panel for the "Start" button ---
        machineActionPanel = new Window("", game.skin);
        TextButton startButton = new TextButton("Start", game.skin);
//        machineActionPanel.add(startButton);
//        machineActionPanel.pack();

        // *** NEW: Create the message label ***
        final Label messageLabel = new Label("", game.skin);

        machineActionPanel.add(startButton).row();
//        // *** NEW: Add the label to the panel's layout ***
//        machineActionPanel.add(messageLabel).minWidth(150).padTop(10);

        // *** NEW: Use a table for better layout control ***
        Table contentTable = new Table();

        // The label will be on the left and will expand to fill empty space
        contentTable.add(messageLabel).expandX().left().pad(5);
        // The button will be on the right
        contentTable.add(startButton).pad(5).padRight(15);

        // Add the table with our organized content to the main panel
        machineActionPanel.add(contentTable);
        machineActionPanel.pack();

        // --- Position everything on screen ---
        playerInventoryUI.setVisible(true);
        machineInputUI.setVisible(true);

        float totalWidth = playerInventoryUI.getWidth() + machineInputUI.getWidth() + machineActionPanel.getWidth() + 30;
        float startX = (hudStage.getWidth() - totalWidth) / 2;

        playerInventoryUI.setPosition(startX, (hudStage.getHeight() - playerInventoryUI.getHeight()) / 2f);
        machineInputUI.setPosition(playerInventoryUI.getX() + playerInventoryUI.getWidth() + 10, playerInventoryUI.getY());
        machineActionPanel.setPosition(machineInputUI.getX() + machineInputUI.getWidth() + 10, machineInputUI.getY());

        hudStage.addActor(machineInputUI);
        hudStage.addActor(machineActionPanel);

        // --- Add listener to the Start button ---
        startButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                boolean isProcessStarted = machine.startProcessing();
                if (isProcessStarted) {
                    closeAllUI();
                } else {
                    // *** NEW: Show the error message on the label ***
                    messageLabel.setText("This is not a valid recipe");
                    machineActionPanel.pack(); // Repack the window to make room for the new text
                }
            }
        });
    }

    private void openMenuUI(final ProcessingMachine machine) {
        closeAllUI(); // Close any other UI first
        activeMachine = machine;

        // Create the menu window on-the-fly
        final Window menu = new Window("Machine Menu", game.skin);

        // --- Dynamically add buttons based on the machine's state ---

        // If the machine is currently processing an item
        if (machine.getState() == ProcessingMachine.MachineState.PROCESSING) {
            TextButton cancelButton = new TextButton("Cancel Process", game.skin);
            TextButton cheatButton = new TextButton("Cheat Finish", game.skin);
            menu.add(cancelButton).width(150).pad(5).row();
            menu.add(cheatButton).width(150).pad(5).row();

            cancelButton.addListener(new ChangeListener() {
                @Override
                public void changed(ChangeEvent event, Actor actor) {
                    // *** THIS IS THE FIX: The variable is now an ItemStack ***
                    ItemStack ingredientStack = machine.cancelProcessing();
                    if (ingredientStack != null) {
                        // Call the new addItem method that accepts an ItemStack
                        player.getInventory().addItem(ingredientStack);
                        playerInventoryUI.refresh();
                    }
                    closeAllUI();
                }
            });

            cheatButton.addListener(new ChangeListener() {
                @Override
                public void changed(ChangeEvent event, Actor actor) {
                    machine.cheatFinish();
                    closeAllUI();
                }
            });
        }

        // If the machine has a finished product ready for collection
        if (machine.getState() == ProcessingMachine.MachineState.FINISHED) {
            TextButton claimButton = new TextButton("Claim Product", game.skin);
            menu.add(claimButton).width(150).pad(5).row();

            claimButton.addListener(new ChangeListener() {
                @Override
                public void changed(ChangeEvent event, Actor actor) {
                    Item product = machine.collectProduct();
                    if (product != null) {
                        player.getInventory().addItem(product);
                        playerInventoryUI.refresh();
                    }
                    closeAllUI();
                }
            });
        }

        // Always add a "Close" button
        TextButton closeButton = new TextButton("Close", game.skin);
        menu.add(closeButton).width(150).pad(5).row();
        closeButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                closeAllUI();
            }
        });

        menu.pack(); // Size the window to fit the buttons

        // Position the menu at the mouse cursor's location
        menu.setPosition(Gdx.input.getX(), Gdx.graphics.getHeight() - Gdx.input.getY() - menu.getHeight());

        currentMenuUI = menu;
        hudStage.addActor(currentMenuUI);
    }

    // --- Cursor Item Management ---
    public void setItemOnCursor(Inventory sourceInventory, int sourceIndex) {
        if (this.itemOnCursor != null) {
            // Swap items
            ItemStack itemToSwap = sourceInventory.removeItem(sourceIndex);
            if (itemToSwap != null) {
                itemOnCursorSourceInventory.addItem(this.itemOnCursor);
                this.itemOnCursor = itemToSwap;
                this.itemOnCursorSourceInventory = sourceInventory;
            }
        } else {
            // Pick up item
            this.itemOnCursor = sourceInventory.removeItem(sourceIndex);
            this.itemOnCursorSourceInventory = sourceInventory;
        }
        playerInventoryUI.refresh();
        if (chestInventoryUI != null) chestInventoryUI.refresh();
    }

    public void setItemOnCursor(ItemStack stack) {
        if (this.itemOnCursor != null) return;
        this.itemOnCursor = stack;
        this.itemOnCursorSourceInventory = null;
    }

//    public void setItemOnCursor(Item item) {
//        if (this.itemOnCursor != null) {
//            // If already holding an item, we can't pick up another one this way.
//            // For now, we'll just ignore the action to prevent bugs.
//            return;
//        }
//        this.itemOnCursor = item;
//        // The source is the machine, so we set the source inventory to null.
//        this.itemOnCursorSourceInventory = null;
//    }

    public ItemStack getItemFromCursor() { return itemOnCursor; }
    public void clearItemFromCursor() {
        this.itemOnCursor = null;
        this.itemOnCursorSourceInventory = null;
        this.itemOnCursorSourceIndex = -1;
    }

    // *** NEW: Methods to manage the machine UI state ***
//    private void openMachineUI(ProcessingMachine machine) {
//        // Close any other UI that might be open
//        closeChestUI();
//        closeInventory();
//
//        activeMachine = machine;
//        currentMachineUI = new MachineUI(machine, game.assetManager, game.skin);
//        currentMachineUI.setPosition(
//            (hudStage.getWidth() - currentMachineUI.getWidth()) / 2,
//            hudStage.getHeight() * 0.6f // Position it in the upper-middle part of the screen
//        );
//        currentMachineUI.setVisible(true);
//        hudStage.addActor(currentMachineUI);
//    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(hudStage);
    }
    @Override
    public void resize(int width, int height) {
        camera.setToOrtho(false, width, height);
        hudStage.getViewport().update(width, height, true);
        playerInventoryUI.setPosition(
            (hudStage.getWidth() - playerInventoryUI.getWidth()) / 2,
            (hudStage.getHeight() - playerInventoryUI.getHeight()) / 2
        );
    }
    @Override
    public void dispose() {
        hudStage.dispose();
    }
    @Override
    public void pause() {}
    @Override
    public void resume() {}
    @Override
    public void hide() {}
}
