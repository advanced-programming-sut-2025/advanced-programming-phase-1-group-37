// File: com/Tools/ToolsGame.java
package com.Tools;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.Gdx;

public class ToolsGame extends Game {

    public SpriteBatch batch;
    public Skin skin;
    public AssetManager assetManager; // *** NEW: The asset manager ***

    @Override
    public void create() {
        batch = new SpriteBatch();
        skin = new Skin(Gdx.files.internal("uiskin.json"));

        // *** NEW: Create and load assets ***
        assetManager = new AssetManager();
        assetManager.loadAssets();

        // Pass the asset manager to the game screen
        this.setScreen(new GameScreen(this));
    }

    @Override
    public void dispose() {
        batch.dispose();
        skin.dispose();
        assetManager.dispose(); // *** NEW: Dispose of assets ***
    }
}
