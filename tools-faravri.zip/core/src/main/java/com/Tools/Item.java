// File: com/Tools/Item.java
package com.Tools;

public class Item {
    private final String name;
    private final String description;
    private final boolean isStackable; // *** NEW ***
    private final int maxStackSize;    // *** NEW ***

    // Constructor for non-stackable items (like tools)
    public Item(String name, String description) {
        this.name = name;
        this.description = description;
        this.isStackable = false;
        this.maxStackSize = 1;
    }

    // Constructor for stackable items (like wood)
    public Item(String name, String description, int maxStackSize) {
        this.name = name;
        this.description = description;
        this.isStackable = true;
        this.maxStackSize = maxStackSize;
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public boolean isStackable() { return isStackable; }
    public int getMaxStackSize() { return maxStackSize; }
}
