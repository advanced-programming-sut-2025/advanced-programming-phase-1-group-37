// File: com/Tools/Inventory.java
package com.Tools;

import java.util.ArrayList;
import java.util.List;

public class Inventory {
    private final List<ItemStack> stacks;
    private final int capacity;

    public Inventory(int capacity) {
        this.capacity = capacity;
        this.stacks = new ArrayList<>();
    }

    public boolean addItem(Item itemToAdd) {
        if (itemToAdd.isStackable()) {
            for (ItemStack stack : stacks) {
                if (stack.getItem().getName().equals(itemToAdd.getName()) && stack.getQuantity() < stack.getItem().getMaxStackSize()) {
                    stack.addQuantity(1);
                    return true;
                }
            }
        }
        if (stacks.size() < capacity) {
            stacks.add(new ItemStack(itemToAdd, 1));
            return true;
        }
        return false;
    }

    public boolean addItem(ItemStack stackToAdd) {
        if (stackToAdd == null) return false;
        if (stacks.size() < capacity) {
            stacks.add(stackToAdd);
            return true;
        }
        return false;
    }

    public ItemStack removeItem(int index) {
        if (index >= 0 && index < stacks.size()) {
            return stacks.remove(index);
        }
        return null;
    }

    // *** NEW: Method to take just one item from a stack ***
    public void takeOneFromStack(int index) {
        if (index >= 0 && index < stacks.size()) {
            ItemStack stack = stacks.get(index);
            stack.setQuantity(stack.getQuantity() - 1);
            // If the stack is now empty, remove it completely.
            if (stack.getQuantity() <= 0) {
                stacks.remove(index);
            }
        }
    }

    public List<ItemStack> getStacks() {
        return stacks;
    }

    public int getCapacity() {
        return capacity;
    }

    public boolean isFull() {
        if (stacks.size() < capacity) return false;
        for (ItemStack stack : stacks) {
            if (stack.getItem().isStackable() && stack.getQuantity() < stack.getItem().getMaxStackSize()) {
                return false;
            }
        }
        return true;
    }
}
