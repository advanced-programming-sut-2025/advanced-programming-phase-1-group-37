// File: com/Tools/ItemStack.java
package com.Tools;

public class ItemStack {
    private final Item item;
    private int quantity;

    public ItemStack(Item item, int quantity) {
        this.item = item;
        this.quantity = quantity;
    }

    public Item getItem() {
        return item;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void addQuantity(int amount) {
        this.quantity += amount;
    }

    // A helper to check if two stacks contain the same type of item
    public boolean isSameType(ItemStack other) {
        return this.item.getName().equals(other.getItem().getName());
    }
}
