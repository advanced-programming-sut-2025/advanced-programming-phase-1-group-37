// File: com/Tools/MachineItem.java
package com.Tools;

// This class represents a placable machine when it's in an inventory.
public class MachineItem extends Item {
    private final Recipe recipe;

    public MachineItem(String name, String description, Recipe recipe) {
        super(name, description);
        this.recipe = recipe;
    }

    public Recipe getRecipe() {
        return recipe;
    }
}
