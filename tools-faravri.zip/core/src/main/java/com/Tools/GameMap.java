// File: com/Tools/GameMap.java
package com.Tools;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GameMap {
    private int width;
    private int height;
    private final List<Tree> trees;
    private final List<WorldItem> droppedItems;
    private final List<Chest> chests; // *** NEW: A list to hold chests ***
    private final List<ProcessingMachine> machines; // *** NEW ***

    public GameMap(int width, int height) {
        this.width = width;
        this.height = height;
        this.trees = new ArrayList<>();
        this.droppedItems = new ArrayList<>();
        this.chests = new ArrayList<>(); // *** NEW: Initialize the list ***
        this.machines = new ArrayList<>(); // *** NEW ***
    }

    public void spawnTrees(int numberOfTrees) {
        Random random = new Random();
        for (int i = 0; i < numberOfTrees; i++) {
            float x = random.nextInt(width - 200) + 100;
            float y = random.nextInt(height - 200) + 100;
            trees.add(new Tree(x, y));
        }
    }

    public void addDroppedItem(WorldItem item) {
        droppedItems.add(item);
    }

    // *** NEW: Method to remove an item from the world ***
    public void removeDroppedItem(WorldItem item) {
        droppedItems.remove(item);
    }

    public List<Tree> getTrees() { return trees; }
    public List<WorldItem> getDroppedItems() { return droppedItems; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }

    public void addChest(Chest chest) {
        chests.add(chest);
    }

    public List<Chest> getChests() { return chests; }

    // *** NEW: Method to add a machine ***
    public void addMachine(ProcessingMachine machine) {
        machines.add(machine);
    }

    // *** NEW: Getter for the machines list ***
    public List<ProcessingMachine> getMachines() { return machines; }
}
