// File: com/Tools/Tool.java
package com.Tools;

public class Tool extends Item {
    private int energyCost;

    public Tool(String name, String description, int energyCost) {
        super(name, description);
        this.energyCost = energyCost;
    }

    public int getEnergyCost() {
        return energyCost;
    }
}
