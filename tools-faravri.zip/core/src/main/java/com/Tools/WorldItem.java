// File: com/Tools/WorldItem.java
package com.Tools;

import com.badlogic.gdx.math.Rectangle; // Import Rectangle

public class WorldItem {
    private float x, y;
    private String name;
    private Rectangle hitbox; // *** NEW: Hitbox for the dropped item ***

    public WorldItem(String name, float x, float y) {
        this.name = name;
        this.x = x;
        this.y = y;
        // *** NEW: Initialize the hitbox. Size is 32x32 for a piece of wood. ***
        this.hitbox = new Rectangle(x, y, 32, 32);
    }

    public String getName() { return name; }
    public float getX() { return x; }
    public float getY() { return y; }
    public Rectangle getHitbox() { return hitbox; } // *** NEW: Getter for hitbox ***
}
