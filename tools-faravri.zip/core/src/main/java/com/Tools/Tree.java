package com.Tools;

import com.badlogic.gdx.math.Rectangle;

public class Tree {
    private float x, y;
    private int health;
    private Rectangle hitbox;

    public Tree(float x, float y) {
        this.x = x;
        this.y = y;
        this.health = 3; // A tree can be hit 3 times
        // The hitbox is a rectangle representing the tree's clickable area.
        // We can adjust the size (e.g., 64x64) and offset as needed.
        this.hitbox = new Rectangle(x, y, 100, 150);
    }

    // Method to call when the tree is hit
    public void hit() {
        if (health > 0) {
            health--;
            System.out.println("Tree was hit! Health is now " + health);
        }
    }

    public boolean isBroken() {
        return health <= 0;
    }

    // This method returns the correct texture name based on the tree's health
    public String getTextureName() {
        if (health == 3) {
            return "Tree_1";
        } else if (health > 0) {
            return "Tree_2";
        } else {
            return "Tree_3"; // The stump
        }
    }

    public float getX() { return x; }
    public float getY() { return y; }
    public Rectangle getHitbox() { return hitbox; }
}
